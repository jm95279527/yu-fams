-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: xm-assets
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色标识',
  `role_id` int DEFAULT NULL COMMENT '系统角色ID',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '电话',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (4,'admin','admin123','系统管理员',NULL,'ADMIN',1,NULL,NULL),(11,'吴津霞','123','吴津霞',NULL,'ADMIN',2,NULL,NULL);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_config`
--

DROP TABLE IF EXISTS `api_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_config` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '接口名称',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '接口描述',
  `url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '接口URL',
  `method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'GET' COMMENT '请求方法(GET、POST、PUT、DELETE)',
  `headers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '请求头(JSON格式)',
  `parameters` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '请求参数(JSON格式)',
  `response_format` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'JSON' COMMENT '响应格式(JSON、XML、TEXT)',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '启用' COMMENT '接口状态(启用、禁用)',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '内部接口' COMMENT '接口类型(内部接口、外部接口)',
  `auth_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '无认证' COMMENT '认证方式(无认证、Token、OAuth2、API Key)',
  `auth_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '认证信息(JSON格式)',
  `timeout` int DEFAULT '30' COMMENT '超时时间(秒)',
  `retry_count` int DEFAULT '0' COMMENT '重试次数',
  `creator_id` int NOT NULL COMMENT '创建人ID',
  `creator_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '创建人姓名',
  `create_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_name` (`name`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_type` (`type`) USING BTREE,
  KEY `idx_creator_id` (`creator_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='接口配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_config`
--

LOCK TABLES `api_config` WRITE;
/*!40000 ALTER TABLE `api_config` DISABLE KEYS */;
INSERT INTO `api_config` VALUES (6,'获取资产列表','获取所有资产信息','/api/assets/list','GET','{\"Content-Type\": \"application/json\"}','{\"page\": 1, \"size\": 10}','JSON','启用','内部接口','Token','{\"token\": \"xxx\"}',30,3,1,'张三','2024-01-01 10:00:00','2024-01-01 10:00:00'),(7,'创建资产','创建新的资产记录','/api/assets/create','POST','{\"Content-Type\": \"application/json\"}','{\"name\": \"资产名称\", \"category\": \"分类\"}','JSON','启用','内部接口','Token','{\"token\": \"xxx\"}',30,3,1,'张三','2024-01-01 10:00:00','2024-01-01 10:00:00'),(8,'更新资产','更新资产信息','/api/assets/update','PUT','{\"Content-Type\": \"application/json\"}','{\"id\": 1, \"name\": \"新名称\"}','JSON','启用','内部接口','Token','{\"token\": \"xxx\"}',30,3,1,'张三','2024-01-01 10:00:00','2024-01-01 10:00:00'),(9,'删除资产','删除指定资产','/api/assets/delete','DELETE','{\"Content-Type\": \"application/json\"}','{\"id\": 1}','JSON','启用','内部接口','Token','{\"token\": \"xxx\"}',30,3,1,'张三','2024-01-01 10:00:00','2024-01-01 10:00:00'),(10,'外部天气API','获取天气信息','https://api.weather.com/current','GET','{\"Accept\": \"application/json\"}','{\"city\": \"北京\"}','JSON','启用','外部接口','API Key','{\"api_key\": \"xxx\"}',60,2,1,'张三','2024-01-01 10:00:00','2024-01-01 10:00:00');
/*!40000 ALTER TABLE `api_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_field_config`
--

DROP TABLE IF EXISTS `asset_field_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_field_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `field_key` varchar(50) NOT NULL COMMENT '字段标识：系统字段=实体属性名，自定义字段=custom1..custom10',
  `label` varchar(50) NOT NULL COMMENT '显示名称',
  `field_type` varchar(20) NOT NULL DEFAULT 'text' COMMENT 'text/number/date/select',
  `options` varchar(500) DEFAULT NULL COMMENT '下拉选项，逗号分隔',
  `enabled` tinyint NOT NULL DEFAULT '1' COMMENT '1启用 0停用',
  `is_system` tinyint NOT NULL DEFAULT '0' COMMENT '1系统字段 0自定义字段',
  `sort_num` int NOT NULL DEFAULT '0',
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_field_key` (`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='资产字段配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_field_config`
--

LOCK TABLES `asset_field_config` WRITE;
/*!40000 ALTER TABLE `asset_field_config` DISABLE KEYS */;
INSERT INTO `asset_field_config` VALUES (1,'no','资产编号','text',NULL,1,1,10,'2026-10-17 13:05:19'),(2,'name','资产名称','text',NULL,1,1,20,'2026-10-17 13:05:19'),(3,'category','资产分类','text',NULL,1,1,30,'2026-10-17 13:05:19'),(4,'img','资产图片','text',NULL,1,1,40,'2026-10-17 13:05:19'),(5,'model','资产型号','text',NULL,1,1,50,'2026-10-17 13:05:19'),(6,'num','数量','number',NULL,1,1,60,'2026-10-17 13:05:19'),(7,'date','购置日期','date',NULL,1,1,70,'2026-10-17 13:05:19'),(8,'money','初始价值','number',NULL,1,1,80,'2026-10-17 13:05:19'),(9,'depreciate','折旧方法','text',NULL,1,1,90,'2026-10-17 13:05:19'),(10,'companyName','所属公司','text',NULL,1,1,100,'2026-10-17 13:05:19'),(11,'departmentName','使用部门','text',NULL,1,1,110,'2026-10-17 13:05:19'),(12,'staffName','使用人','text',NULL,1,1,120,'2026-10-17 13:05:19'),(13,'location','存放地点','text',NULL,1,1,130,'2026-10-17 13:05:19'),(14,'status','资产状态','text',NULL,1,1,140,'2026-10-17 13:05:19'),(15,'comment','备注','text',NULL,1,1,150,'2026-10-17 13:05:19'),(16,'custom1','自定义字段1','text','',0,0,201,'2026-10-17 13:05:19'),(17,'custom2','自定义字段2','text','',0,0,202,'2026-10-17 13:05:19'),(18,'custom3','自定义字段3','text','',0,0,203,'2026-10-17 13:05:19'),(19,'custom4','自定义字段4','text','',0,0,204,'2026-10-17 13:05:19'),(20,'custom5','自定义字段5','text','',0,0,205,'2026-10-17 13:05:19'),(21,'custom6','自定义字段6','text','',0,0,206,'2026-10-17 13:05:19'),(22,'custom7','自定义字段7','text','',0,0,207,'2026-10-17 13:05:19'),(23,'custom8','自定义字段8','text','',0,0,208,'2026-10-17 13:05:19'),(24,'custom9','自定义字段9','text','',0,0,209,'2026-10-17 13:05:19'),(25,'custom10','自定义字段10','text','',0,0,210,'2026-10-17 13:05:19');
/*!40000 ALTER TABLE `asset_field_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产分类',
  `no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产编号',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产图片',
  `model` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产型号',
  `num` int DEFAULT NULL COMMENT '数量',
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '购置日期',
  `money` decimal(10,2) DEFAULT NULL COMMENT '初始价值',
  `current_value` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '当前价值',
  `depreciate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '折旧方法',
  `depreciation_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '折旧率',
  `department_id` int DEFAULT NULL COMMENT '使用部门ID',
  `staff_id` int DEFAULT NULL COMMENT '责任人',
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '存放地点',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `custom1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom5` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom6` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom7` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom8` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom9` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom10` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='资产信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (125,'华硕笔记本电脑','笔记本电脑','HM-DZ012026090001',NULL,'华硕无畏14',1,NULL,NULL,0.00,NULL,0.00,37,34,'36栋','正常',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(126,'笔记本电脑','笔记本电脑','HM-DZ012026100001',NULL,NULL,1,'2026-10-14',NULL,0.00,NULL,0.00,NULL,NULL,NULL,'正常',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_detail`
--

DROP TABLE IF EXISTS `assets_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_detail` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `assets_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产名称',
  `assets_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产编号',
  `operation_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作类型(入库、领用、调拨、维修、盘点、报废等)',
  `operation_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作时间',
  `operator_id` int NOT NULL COMMENT '操作人ID',
  `operator_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作人姓名',
  `before_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作前状态',
  `after_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作后状态',
  `before_staff_id` int DEFAULT NULL COMMENT '操作前使用人ID',
  `before_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作前使用人姓名',
  `after_staff_id` int DEFAULT NULL COMMENT '操作后使用人ID',
  `after_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作后使用人姓名',
  `before_department_id` int DEFAULT NULL COMMENT '操作前部门ID',
  `before_department_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作前部门名称',
  `after_department_id` int DEFAULT NULL COMMENT '操作后部门ID',
  `after_department_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作后部门名称',
  `before_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作前位置',
  `after_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作后位置',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作描述',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '备注',
  `create_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_assets_id` (`assets_id`) USING BTREE,
  KEY `idx_operation_type` (`operation_type`) USING BTREE,
  KEY `idx_operation_time` (`operation_time`) USING BTREE,
  KEY `idx_operator_id` (`operator_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='资产详情记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_detail`
--

LOCK TABLES `assets_detail` WRITE;
/*!40000 ALTER TABLE `assets_detail` DISABLE KEYS */;
INSERT INTO `assets_detail` VALUES (8,1,'办公电脑','ZC001','入库','2024-01-01 09:00:00',1,'张三',NULL,'库存',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'仓库A区','资产入库','新购入资产','2024-01-01 09:00:00'),(9,1,'办公电脑','ZC001','领用','2024-01-02 10:00:00',1,'张三','库存','使用中',NULL,NULL,1,'张三',NULL,NULL,1,'技术部','仓库A区','办公室A区','资产领用','正常领用','2024-01-02 10:00:00'),(10,1,'办公电脑','ZC001','调拨','2024-01-15 10:00:00',1,'张三','使用中','使用中',1,'张三',2,'李四',1,'技术部',2,'销售部','办公室A区','办公室B区','资产调拨','工作需要调拨','2024-01-15 10:00:00'),(11,2,'打印机','ZC002','入库','2024-01-03 14:00:00',1,'张三',NULL,'库存',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'仓库B区','资产入库','新购入资产','2024-01-03 14:00:00'),(12,2,'打印机','ZC002','领用','2024-01-04 15:00:00',2,'李四','库存','使用中',NULL,NULL,2,'李四',NULL,NULL,2,'销售部','仓库B区','办公室B区','资产领用','正常领用','2024-01-04 15:00:00'),(13,3,'投影仪','ZC003','入库','2024-01-05 11:00:00',1,'张三',NULL,'库存',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'仓库C区','资产入库','新购入资产','2024-01-05 11:00:00'),(14,3,'投影仪','ZC003','领用','2024-01-06 16:00:00',3,'王五','库存','使用中',NULL,NULL,3,'王五',NULL,NULL,3,'财务部','仓库C区','会议室','资产领用','正常领用','2024-01-06 16:00:00'),(18,100,'示例资产','HM-CAT2026090001','调拨','2026-09-12 15:44:55',4,'系统管理员','正常','正常',NULL,NULL,NULL,NULL,NULL,NULL,13,'11','办公室','办公室','资产调拨：-/- → 11/-','1','2026-09-12 15:44:55'),(21,107,'123','HM-DZ012026090001','调拨','2026-09-14 09:38:39',4,'系统管理员',NULL,NULL,NULL,NULL,NULL,NULL,12,'hena',12,'hena',NULL,'111','资产调拨：hena/- → hena/-','111','2026-09-14 09:38:39'),(22,118,'11','HM-dyj2026090001','调拨','2026-09-14 17:45:00',4,'系统管理员','正常','正常',NULL,NULL,NULL,NULL,NULL,NULL,13,'11',NULL,'11','资产调拨：-/- → 11/-','11','2026-09-14 17:45:00');
/*!40000 ALTER TABLE `assets_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_in`
--

DROP TABLE IF EXISTS `assets_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_in` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `assets_id` int DEFAULT NULL COMMENT '资产ID',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产分类',
  `model` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '规格型号',
  `num` int DEFAULT NULL COMMENT '入库数量',
  `money` decimal(12,2) DEFAULT NULL COMMENT '初始价值(单价)',
  `depreciate` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '折旧方法',
  `purchase_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '采购单号',
  `supplier` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '供应商',
  `department_id` int DEFAULT NULL COMMENT '使用部门ID',
  `manager_id` int DEFAULT NULL COMMENT '责任人ID',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '存放地点',
  `img` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产图片',
  `staff_id` int DEFAULT NULL COMMENT '操作人ID',
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '入库日期',
  `accept_date` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验收日期',
  `accept_user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验收人',
  `accept_result` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验收意见',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核状态',
  `audit_user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核人',
  `audit_date` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核日期',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '驳回原因',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='资产入库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_in`
--

LOCK TABLES `assets_in` WRITE;
/*!40000 ALTER TABLE `assets_in` DISABLE KEYS */;
INSERT INTO `assets_in` VALUES (10,32,'台式机','主机',NULL,1,NULL,NULL,NULL,NULL,12,NULL,NULL,NULL,NULL,'2026-09-12','2026-09-12',NULL,NULL,NULL,'通过','系统管理员','2026-09-12 13:54:05',NULL),(13,117,'示例笔记本电脑','办公设备','ThinkPad X1',10,6500.00,'直线法','CG20260912001','联想供应商',NULL,NULL,'办公楼3层仓库',NULL,4,'2026-09-12','2026-09-12','张三','验收合格','备注示例','通过','系统管理员','2026-09-14 15:22:50',NULL),(29,126,'笔记本电脑','笔记本电脑',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,'2026-10-14','2026-10-14',NULL,NULL,NULL,'通过','系统管理员','2026-10-14 14:26:18',NULL);
/*!40000 ALTER TABLE `assets_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_receive`
--

DROP TABLE IF EXISTS `assets_receive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_receive` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `assets_id` int DEFAULT NULL COMMENT '资产ID',
  `staff_id` int DEFAULT NULL COMMENT '用户ID',
  `borrower_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '借用人姓名（手工填写）',
  `borrower_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '借用人联系方式',
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '领用日期',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `return_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '归还日期',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核状态',
  `return_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '归还状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='资产领用';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_receive`
--

LOCK TABLES `assets_receive` WRITE;
/*!40000 ALTER TABLE `assets_receive` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_receive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_repair`
--

DROP TABLE IF EXISTS `assets_repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_repair` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `assets_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `assets_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产编号',
  `receive_id` int DEFAULT NULL COMMENT '资产领用ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '处理中' COMMENT '维修状态（处理中、已完成）',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报修理由',
  `fault_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '故障描述',
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报修照片',
  `repair_result` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '维修结果',
  `complete_time` datetime DEFAULT NULL COMMENT '完成时间',
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报修日期',
  `staff_id` int DEFAULT NULL COMMENT '报修人',
  `reporter_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报修人姓名（手工填写）',
  `reporter_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报修人联系方式',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='资产报修';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_repair`
--

LOCK TABLES `assets_repair` WRITE;
/*!40000 ALTER TABLE `assets_repair` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_repair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_scrap`
--

DROP TABLE IF EXISTS `assets_scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_scrap` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `assets_no` varchar(64) DEFAULT NULL COMMENT '资产编号（快照）',
  `assets_name` varchar(128) DEFAULT NULL COMMENT '资产名称（快照）',
  `category` varchar(64) DEFAULT NULL COMMENT '分类（快照）',
  `model` varchar(128) DEFAULT NULL COMMENT '型号（快照）',
  `money` decimal(12,2) DEFAULT NULL COMMENT '原值（快照）',
  `depreciate` varchar(64) DEFAULT NULL COMMENT '折旧方式（快照）',
  `department_id` int DEFAULT NULL COMMENT '部门ID（快照）',
  `department_name` varchar(64) DEFAULT NULL COMMENT '部门名称（快照）',
  `staff_id` int DEFAULT NULL COMMENT '责任人ID（快照）',
  `staff_name` varchar(64) DEFAULT NULL COMMENT '责任人名称（快照）',
  `location` varchar(255) DEFAULT NULL COMMENT '存放地点（快照）',
  `scrap_type` varchar(32) DEFAULT NULL COMMENT '报废类型：正常报废/毁损/丢失/其他',
  `reason` varchar(500) DEFAULT NULL COMMENT '报废原因',
  `residual_value` decimal(12,2) DEFAULT '0.00' COMMENT '残值',
  `apply_time` datetime DEFAULT NULL COMMENT '申请时间',
  `applicant_id` int DEFAULT NULL COMMENT '申请人ID',
  `applicant_name` varchar(64) DEFAULT NULL COMMENT '申请人姓名',
  `status` varchar(20) DEFAULT '待审批' COMMENT '状态：待审批/已报废/已拒绝',
  `approver_id` int DEFAULT NULL COMMENT '审批人ID',
  `approver_name` varchar(64) DEFAULT NULL COMMENT '审批人姓名',
  `approve_time` datetime DEFAULT NULL COMMENT '审批时间',
  `approve_comment` varchar(500) DEFAULT NULL COMMENT '审批意见/驳回原因',
  `comment` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_assets_id` (`assets_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=99993 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='资产报废单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_scrap`
--

LOCK TABLES `assets_scrap` WRITE;
/*!40000 ALTER TABLE `assets_scrap` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_scrap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_transfer`
--

DROP TABLE IF EXISTS `assets_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_transfer` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `assets_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产名称',
  `assets_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产编号',
  `transfer_time` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '调拨时间',
  `transfer_staff_id` int DEFAULT NULL COMMENT '调拨经办人，孤儿修复后可空',
  `transfer_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '调拨人姓名',
  `from_staff_id` int DEFAULT NULL COMMENT '原使用人ID',
  `from_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原使用人姓名',
  `from_department_id` int DEFAULT NULL COMMENT '原部门ID',
  `from_department_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原部门名称',
  `from_location` varchar(200) DEFAULT NULL COMMENT '原存放地点',
  `to_staff_id` int DEFAULT NULL,
  `to_staff_name` varchar(50) DEFAULT NULL,
  `to_department_id` int DEFAULT NULL,
  `to_department_name` varchar(50) DEFAULT NULL,
  `to_location` varchar(200) DEFAULT NULL COMMENT '新存放地点',
  `reason` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '调拨原因',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '待审批' COMMENT '调拨状态(待审批、已审批、已调拨、已拒绝)',
  `approver_id` int DEFAULT NULL COMMENT '审批人ID',
  `approver_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批人姓名',
  `approve_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批时间',
  `approve_comment` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批意见',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '备注',
  `create_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_assets_id` (`assets_id`) USING BTREE,
  KEY `idx_transfer_staff_id` (`transfer_staff_id`) USING BTREE,
  KEY `idx_from_staff_id` (`from_staff_id`) USING BTREE,
  KEY `idx_to_staff_id` (`to_staff_id`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_transfer_time` (`transfer_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='资产调拨表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_transfer`
--

LOCK TABLES `assets_transfer` WRITE;
/*!40000 ALTER TABLE `assets_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人账号',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色 ADMIN/STAFF',
  `ip` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '来源IP',
  `method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'HTTP方法',
  `uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求接口',
  `params` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求参数(已脱敏)',
  `result_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务码',
  `status` int DEFAULT NULL COMMENT 'HTTP状态码',
  `cost_ms` int DEFAULT NULL COMMENT '耗时毫秒',
  `create_time` datetime DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `idx_al_user` (`username`),
  KEY `idx_al_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=450 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作审计日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES (1,'unknown',NULL,'0:0:0:0:0:0:0:1','POST','/login','{}','4001',200,137,'2026-09-13 13:26:26'),(2,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,95,'2026-09-13 13:26:36'),(3,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/staff/add','{\"username\":\"guard_t\",\"name\":\"防爆破测试\",\"password\":\"***\",\"status\":\"在职\"}','200',200,71,'2026-09-13 13:26:36'),(4,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','5003',200,9,'2026-09-13 13:26:36'),(5,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','5003',200,5,'2026-09-13 13:26:36'),(6,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','5003',200,5,'2026-09-13 13:26:36'),(7,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','5003',200,5,'2026-09-13 13:26:36'),(8,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','5003',200,5,'2026-09-13 13:26:36'),(9,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','400',200,2,'2026-09-13 13:26:36'),(10,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','400',200,1,'2026-09-13 13:26:36'),(11,'guard_t','STAFF','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"guard_t\",\"password\":\"***\",\"role\":\"STAFF\"}','200',200,512,'2026-09-13 13:26:54'),(12,'admin','ADMIN','0:0:0:0:0:0:0:1','DELETE','/staff/delete/25',NULL,'200',200,91,'2026-09-13 13:26:54'),(13,'admin','ADMIN','0:0:0:0:0:0:0:1','DELETE','/auditLog/clean/365',NULL,'200',200,14,'2026-09-13 13:26:54'),(14,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,10,'2026-09-13 13:27:29'),(15,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,8,'2026-09-14 08:30:10'),(16,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,506,'2026-09-14 09:04:03'),(17,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,8,'2026-09-14 09:06:03'),(18,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/add','{\"name\":\"RF盘点_部门12\",\"scopeType\":\"DEPT\",\"scopeId\":12}','200',200,98,'2026-09-14 09:06:03'),(19,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/5','{\"code\":\"26\"}','200',200,115,'2026-09-14 09:06:03'),(20,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/5','{\"code\":\"32\",\"abnormal\":true,\"actualLocation\":\"仓库B\",\"comment\":\"地点不符\"}','200',200,38,'2026-09-14 09:06:03'),(21,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/markItem/27','{\"itemStatus\":\"正常\"}','200',200,20,'2026-09-14 09:06:03'),(22,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/markItem/27','{\"itemStatus\":\"异常\"}','200',200,27,'2026-09-14 09:06:03'),(23,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/27','{}','500',200,16,'2026-09-14 09:06:03'),(24,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/27','{\"dealType\":\"报损\"}','500',200,12,'2026-09-14 09:06:03'),(25,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/27','{\"dealType\":\"调拨修正\",\"dealRemark\":\"已调至仓库B\"}','200',200,22,'2026-09-14 09:06:03'),(26,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/27','{\"dealType\":\"信息更正\"}','500',200,13,'2026-09-14 09:06:04'),(27,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/5','{\"code\":\"27\"}','200',200,23,'2026-09-14 09:06:04'),(28,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/finish/5',NULL,'200',200,19,'2026-09-14 09:06:04'),(29,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/29','{\"dealType\":\"补录入账\",\"dealRemark\":\"补录台账\"}','200',200,19,'2026-09-14 09:06:04'),(30,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/28','{\"dealType\":\"误盘\"}','500',200,12,'2026-09-14 09:06:04'),(31,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/add','{\"name\":\"RF盘点_部门13\",\"scopeType\":\"DEPT\",\"scopeId\":13}','200',200,17,'2026-09-14 09:06:04'),(32,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/finish/6',NULL,'200',200,20,'2026-09-14 09:06:04'),(33,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/30','{\"dealType\":\"报损\",\"dealRemark\":\"走报废流程\"}','200',200,24,'2026-09-14 09:06:04'),(34,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,516,'2026-09-14 09:11:38'),(35,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/add','{\"name\":\"RF盘点_部门12\",\"scopeType\":\"DEPT\",\"scopeId\":12}','200',200,121,'2026-09-14 09:11:38'),(36,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/7','{\"code\":\"26\"}','200',200,116,'2026-09-14 09:11:39'),(37,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/7','{\"code\":\"32\",\"abnormal\":true,\"actualLocation\":\"仓库B\",\"comment\":\"地点不符\"}','200',200,29,'2026-09-14 09:11:39'),(38,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/markItem/32','{\"itemStatus\":\"正常\"}','200',200,20,'2026-09-14 09:11:39'),(39,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/markItem/32','{\"itemStatus\":\"异常\"}','200',200,20,'2026-09-14 09:11:39'),(40,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/32','{}','500',200,16,'2026-09-14 09:11:39'),(41,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/32','{\"dealType\":\"报损\"}','500',200,13,'2026-09-14 09:11:39'),(42,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/32','{\"dealType\":\"调拨修正\",\"dealRemark\":\"已调至仓库B\"}','200',200,22,'2026-09-14 09:11:39'),(43,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/32','{\"dealType\":\"信息更正\"}','500',200,13,'2026-09-14 09:11:39'),(44,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/7','{\"code\":\"27\"}','200',200,21,'2026-09-14 09:11:39'),(45,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/finish/7',NULL,'200',200,20,'2026-09-14 09:11:39'),(46,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/34','{\"dealType\":\"补录入账\",\"dealRemark\":\"补录台账\"}','200',200,25,'2026-09-14 09:11:40'),(47,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/33','{\"dealType\":\"误盘\"}','500',200,12,'2026-09-14 09:11:40'),(48,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/add','{\"name\":\"RF盘点_部门13\",\"scopeType\":\"DEPT\",\"scopeId\":13}','200',200,17,'2026-09-14 09:11:40'),(49,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/finish/8',NULL,'200',200,22,'2026-09-14 09:11:40'),(50,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/35','{\"dealType\":\"报损\",\"dealRemark\":\"走报废流程\"}','200',200,23,'2026-09-14 09:11:40'),(51,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 09:14:31'),(52,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,480,'2026-09-14 09:34:56'),(53,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/add','{\"name\":\"RF盘点_部门12\",\"scopeType\":\"DEPT\",\"scopeId\":12}','200',200,100,'2026-09-14 09:34:56'),(54,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/9','{\"code\":\"26\"}','200',200,130,'2026-09-14 09:34:57'),(55,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/9','{\"code\":\"32\",\"abnormal\":true,\"actualLocation\":\"仓库B\",\"comment\":\"地点不符\"}','200',200,28,'2026-09-14 09:34:57'),(56,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/markItem/37','{\"itemStatus\":\"正常\"}','200',200,20,'2026-09-14 09:34:57'),(57,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/markItem/37','{\"itemStatus\":\"异常\"}','200',200,19,'2026-09-14 09:34:57'),(58,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/37','{}','500',200,17,'2026-09-14 09:34:57'),(59,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/37','{\"dealType\":\"报损\"}','500',200,13,'2026-09-14 09:34:57'),(60,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/37','{\"dealType\":\"调拨修正\",\"dealRemark\":\"已调至仓库B\"}','200',200,22,'2026-09-14 09:34:57'),(61,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/37','{\"dealType\":\"信息更正\"}','500',200,13,'2026-09-14 09:34:57'),(62,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/scan/9','{\"code\":\"27\"}','200',200,22,'2026-09-14 09:34:57'),(63,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/finish/9',NULL,'200',200,18,'2026-09-14 09:34:57'),(64,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/39','{\"dealType\":\"补录入账\",\"dealRemark\":\"补录台账\"}','200',200,21,'2026-09-14 09:34:58'),(65,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/38','{\"dealType\":\"误盘\"}','500',200,11,'2026-09-14 09:34:58'),(66,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/add','{\"name\":\"RF盘点_部门13\",\"scopeType\":\"DEPT\",\"scopeId\":13}','200',200,17,'2026-09-14 09:34:58'),(67,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/finish/10',NULL,'200',200,20,'2026-09-14 09:34:58'),(68,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/assetsInventory/dealItem/40','{\"dealType\":\"报损\",\"dealRemark\":\"走报废流程\"}','200',200,23,'2026-09-14 09:34:58'),(69,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-14 09:35:42'),(70,'admin','ADMIN','192.168.20.253','POST','/notice/add','{\"title\":\"测试\",\"content\":\"这是一个测试网站\\n\"}','200',200,12,'2026-09-14 09:36:17'),(71,'admin','ADMIN','192.168.20.253','POST','/assets/add','{\"num\":1,\"name\":\"123\",\"category\":\"显示器\",\"no\":\"HM-DZ012026090001\",\"model\":\"1213\",\"date\":\"2026-09-11\",\"departmentId\":12}','200',200,12,'2026-09-14 09:37:46'),(72,'admin','ADMIN','192.168.20.253','POST','/assetsTransfer/add','{\"assetsId\":107,\"toDepartmentId\":12,\"toStaffId\":null,\"toLocation\":\"111\",\"reason\":\"111\",\"comment\":\"\"}','200',200,21,'2026-09-14 09:38:26'),(73,'admin','ADMIN','192.168.20.253','POST','/assetsTransfer/audit/12','{\"pass\":true}','200',200,25,'2026-09-14 09:38:39'),(74,'admin','ADMIN','192.168.20.253','POST','/assetsInventory/add','{\"name\":\"2026年9月资产盘点\",\"scopeType\":\"ALL\",\"scopeId\":null,\"remark\":\"1\"}','200',200,18,'2026-09-14 09:38:55'),(75,'admin','ADMIN','192.168.20.253','POST','/assetsInventory/scan/11','{\"code\":\"HM-DZ012026090001\",\"actualLocation\":\"\",\"abnormal\":false,\"comment\":\"\"}','200',200,21,'2026-09-14 09:39:11'),(76,'admin','ADMIN','192.168.20.253','POST','/assetsInventory/scan/11','{\"code\":\"HM-CAT2026090007\",\"actualLocation\":\"\",\"abnormal\":false,\"comment\":\"\"}','200',200,17,'2026-09-14 09:39:17'),(77,'admin','ADMIN','192.168.20.253','POST','/assetsInventory/scan/11','{\"code\":\"HM-CAT2026090006\",\"actualLocation\":\"\",\"abnormal\":false,\"comment\":\"\"}','200',200,21,'2026-09-14 09:39:23'),(78,'admin','ADMIN','192.168.20.253','POST','/assetsInventory/scan/11','{\"code\":\"HM-CAT20260900061\",\"actualLocation\":\"\",\"abnormal\":false,\"comment\":\"\"}','500',200,10,'2026-09-14 09:39:25'),(79,'admin','ADMIN','192.168.20.253','POST','/assetsInventory/scan/11','{\"code\":\"HM-CAT20260900061\",\"actualLocation\":\"\",\"abnormal\":false,\"comment\":\"\"}','500',200,10,'2026-09-14 09:39:27'),(80,'admin','ADMIN','192.168.20.253','POST','/category/add','{\"name\":\"打印机\",\"code\":\"dyj\"}','200',200,9,'2026-09-14 09:40:34'),(81,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-14 09:56:11'),(82,'admin','ADMIN','192.168.254.3','POST','/assetsInventory/add','{\"name\":\"2026年9月资产盘点UI盘点_部门12\",\"scopeType\":\"DEPT\",\"scopeId\":12,\"remark\":\"\"}','200',200,12,'2026-09-14 09:56:33'),(83,'admin','ADMIN','192.168.254.3','POST','/assetsInventory/scan/12','{\"code\":\"26\",\"actualLocation\":\"\",\"abnormal\":false,\"comment\":\"\"}','200',200,15,'2026-09-14 09:56:43'),(84,'admin','ADMIN','0:0:0:0:0:0:0:1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 10:00:28'),(85,'admin','ADMIN','0:0:0:0:0:0:0:1','DELETE','/assetsInventory/delete/11',NULL,'200',200,10,'2026-09-14 10:00:28'),(86,'admin','ADMIN','0:0:0:0:0:0:0:1','DELETE','/assetsInventory/delete/12',NULL,'200',200,8,'2026-09-14 10:00:28'),(87,'unknown',NULL,'127.0.0.1','POST','/user/login',NULL,NULL,200,2,'2026-09-14 13:40:26'),(88,'unknown',NULL,'127.0.0.1','POST','/user/login',NULL,NULL,200,1,'2026-09-14 13:40:37'),(89,'unknown',NULL,'127.0.0.1','POST','/user/login',NULL,NULL,200,1,'2026-09-14 13:43:11'),(90,'unknown',NULL,'127.0.0.1','POST','/user/login',NULL,NULL,200,17,'2026-09-14 13:44:32'),(91,'unknown',NULL,'127.0.0.1','POST','/login','{\" username\\:\\admin\\,\\password\\:\\admin123\\,\\role\\:\\ADMIN\\}','500',200,52,'2026-09-14 13:46:46'),(92,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,93,'2026-09-14 13:47:19'),(93,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,6,'2026-09-14 13:47:42'),(94,'admin','ADMIN','127.0.0.1','POST','/inventory/task/add',NULL,NULL,404,46,'2026-09-14 13:47:42'),(95,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 13:48:11'),(96,'admin','ADMIN','127.0.0.1','POST','/inventory/task/add',NULL,NULL,404,10,'2026-09-14 13:48:11'),(97,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,7,'2026-09-14 13:49:13'),(98,'admin','ADMIN','127.0.0.1','POST','/assetsInventory/add','{\"type\":\"全部\",\"departmentId\":\"\",\"name\":\"E2E验证任务\",\"remark\":\"e2e\"}','200',200,62,'2026-09-14 13:49:13'),(99,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 13:49:34'),(100,'admin','ADMIN','127.0.0.1','POST','/assetsInventory/add','{\"type\":\"全部\",\"departmentId\":\"\",\"name\":\"E2E验证任务\",\"remark\":\"e2e\"}','200',200,34,'2026-09-14 13:49:34'),(101,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-14 14:02:58'),(102,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 14:50:06'),(103,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 14:50:11'),(104,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 14:50:53'),(105,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-14 14:54:32'),(106,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-14 14:54:38'),(107,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-14 14:54:50'),(108,'admin','ADMIN','192.168.254.3','POST','/assetsInventory/add','{\"type\":\"全部\",\"name\":\"导出验证任务\"}','200',200,16,'2026-09-14 14:56:54'),(109,'admin','ADMIN','192.168.254.3','DELETE','/assetsInventory/delete/15',NULL,'200',200,10,'2026-09-14 14:56:58'),(110,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-14 14:57:16'),(111,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-14 14:58:28'),(112,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-14 14:58:33'),(113,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,7,'2026-09-14 15:11:40'),(114,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 15:12:14'),(115,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-14 15:12:38'),(116,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,359,'2026-09-14 15:15:34'),(117,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 15:15:58'),(118,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,392,'2026-09-14 15:19:06'),(119,'admin','ADMIN','192.168.20.253','POST','/assetsIn/import',NULL,'200',200,330,'2026-09-14 15:22:23'),(120,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/22','{\"pass\":true,\"rejectReason\":null}','200',200,186,'2026-09-14 15:22:36'),(121,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/21','{\"pass\":true,\"rejectReason\":null}','200',200,43,'2026-09-14 15:22:37'),(122,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/20','{\"pass\":true,\"rejectReason\":null}','200',200,27,'2026-09-14 15:22:39'),(123,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/19','{\"pass\":true,\"rejectReason\":null}','200',200,20,'2026-09-14 15:22:40'),(124,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/18','{\"pass\":true,\"rejectReason\":null}','200',200,20,'2026-09-14 15:22:42'),(125,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/17','{\"pass\":true,\"rejectReason\":null}','200',200,20,'2026-09-14 15:22:44'),(126,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/16','{\"pass\":true,\"rejectReason\":null}','200',200,20,'2026-09-14 15:22:45'),(127,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/15','{\"pass\":true,\"rejectReason\":null}','200',200,20,'2026-09-14 15:22:47'),(128,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/14','{\"pass\":true,\"rejectReason\":null}','200',200,18,'2026-09-14 15:22:49'),(129,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/13','{\"pass\":true,\"rejectReason\":null}','200',200,25,'2026-09-14 15:22:50'),(130,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,397,'2026-09-14 15:25:54'),(131,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,373,'2026-09-14 15:27:46'),(132,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 15:28:02'),(133,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 15:32:27'),(134,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,417,'2026-09-14 15:40:12'),(135,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":117,\"returnDate\":\"2026-12-31\",\"comment\":\"E2E临时验证\"}','200',200,130,'2026-09-14 15:40:12'),(136,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":26,\"assetsId\":117,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,13,'2026-09-14 15:40:12'),(137,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":117,\"assetsName\":\"E2E测试资产\",\"assetsCode\":\"E2E-CODE\",\"reason\":\"E2E理由\",\"faultDesc\":\"E2E故障\"}','200',200,18,'2026-09-14 15:40:13'),(138,'admin','ADMIN','127.0.0.1','PUT','/assetsRepair/update','{\"id\":19,\"status\":\"维修中\"}','200',200,11,'2026-09-14 15:40:13'),(139,'admin','ADMIN','127.0.0.1','PUT','/assetsRepair/update','{\"id\":19,\"status\":\"已完成\",\"repairResult\":\"维修完成\",\"completeTime\":\"2026/9/14 15:40:00\"}','500',200,21,'2026-09-14 15:40:13'),(140,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 15:42:02'),(141,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":117,\"returnDate\":\"2026-12-31\",\"comment\":\"E2E临时\"}','200',200,14,'2026-09-14 15:42:02'),(142,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":117,\"staffId\":9999,\"returnDate\":\"2026-12-31\",\"comment\":\"E2E指定员工\"}','200',200,14,'2026-09-14 15:42:02'),(143,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":27,\"assetsId\":117,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,22,'2026-09-14 15:42:02'),(144,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":117,\"assetsName\":\"E2E测试资产\",\"assetsCode\":\"E2E-CODE\",\"reason\":\"E2E理由\",\"faultDesc\":\"E2E故障\"}','200',200,14,'2026-09-14 15:42:02'),(145,'admin','ADMIN','127.0.0.1','PUT','/assetsRepair/update','{\"id\":20,\"status\":\"维修中\"}','200',200,8,'2026-09-14 15:42:02'),(146,'admin','ADMIN','127.0.0.1','PUT','/assetsRepair/update','{\"id\":20,\"status\":\"已完成\",\"repairResult\":\"维修完成\"}','200',200,14,'2026-09-14 15:42:02'),(147,'admin','ADMIN','127.0.0.1','PUT','/assetsRepair/update','{\"id\":20,\"status\":\"已完成\",\"completeTime\":\"2026/9/14 15:40:00\"}','500',200,11,'2026-09-14 15:42:02'),(148,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,417,'2026-09-14 15:52:40'),(149,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,395,'2026-09-14 15:57:14'),(150,'admin','ADMIN','192.168.200.1','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,12,'2026-09-14 15:59:37'),(151,'admin','ADMIN','192.168.200.1','POST','/assetsRepair/add','{\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"reason\":\"111\",\"faultDesc\":\"111\"}','200',200,202,'2026-09-14 16:23:10'),(152,'admin','ADMIN','192.168.200.1','PUT','/assetsRepair/update','{\"id\":21,\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"receiveId\":null,\"status\":\"维修中\",\"reason\":\"111\",\"faultDesc\":\"111\",\"repairResult\":null,\"completeTime\":null,\"date\":\"2026-09-14 16:23:10\",\"staffId\":4,\"staffName\":null}','200',200,13,'2026-09-14 16:23:13'),(153,'admin','ADMIN','192.168.200.1','PUT','/assetsRepair/update','{\"id\":21,\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"receiveId\":null,\"status\":\"已完成\",\"reason\":\"111\",\"faultDesc\":\"111\",\"repairResult\":null,\"completeTime\":null,\"date\":\"2026-09-14 16:23:10\",\"staffId\":4,\"staffName\":null}','200',200,62,'2026-09-14 16:23:18'),(154,'admin','ADMIN','192.168.200.1','POST','/assetsReceive/add','{\"assetsId\":117,\"returnDate\":\"2026-09-01\",\"comment\":\"1\"}','200',200,13,'2026-09-14 17:23:32'),(155,'admin','ADMIN','192.168.200.1','PUT','/assetsReceive/update','{\"id\":29,\"assetsId\":117,\"staffId\":4,\"date\":\"2026-09-14 17:23:32\",\"comment\":\"1\",\"returnDate\":\"2026-09-01\",\"status\":\"通过\",\"assetsName\":\"示例笔记本电脑\",\"assetsNo\":\"HM-CAT2026090017\",\"staffName\":null,\"returnStatus\":\"未归还\"}','200',200,65,'2026-09-14 17:23:49'),(156,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,371,'2026-09-14 17:30:13'),(157,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E测试机器人\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-test-key\",\"enabled\":true,\"remark\":\"E2E\"}','200',200,180,'2026-09-14 17:30:13'),(158,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":117,\"returnDate\":\"2026-12-31\",\"comment\":\"E2E通知验证\"}','200',200,25,'2026-09-14 17:30:13'),(159,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":30,\"assetsId\":117,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,688,'2026-09-14 17:30:14'),(160,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 17:30:39'),(161,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E测试机器人\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-test-key\",\"enabled\":true}','200',200,10,'2026-09-14 17:30:39'),(162,'admin','ADMIN','127.0.0.1','POST','/robotConfig/test/2',NULL,'200',200,117,'2026-09-14 17:30:39'),(163,'admin','ADMIN','127.0.0.1','POST','/robotConfig/test/2',NULL,'200',200,68,'2026-09-14 17:30:39'),(164,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,400,'2026-09-14 17:31:25'),(165,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-temp\",\"enabled\":true}','200',200,206,'2026-09-14 17:31:25'),(166,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":26,\"returnDate\":\"2026-12-31\",\"comment\":\"E2E通知内容验证\"}','200',200,24,'2026-09-14 17:31:25'),(167,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":31,\"assetsId\":26,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,649,'2026-09-14 17:31:26'),(168,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":26,\"returnDate\":\"2026-12-31\",\"comment\":\"E2E停用模板验证\"}','500',200,15,'2026-09-14 17:31:27'),(169,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":,\"assetsId\":26,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','500',200,14,'2026-09-14 17:31:27'),(170,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 17:31:51'),(171,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-temp\",\"enabled\":true}','200',200,10,'2026-09-14 17:31:51'),(172,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":101,\"returnDate\":\"2026-12-31\",\"comment\":\"A启用模板\"}','200',200,13,'2026-09-14 17:31:51'),(173,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":32,\"assetsId\":101,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,156,'2026-09-14 17:31:51'),(174,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":101,\"returnDate\":\"2026-12-31\",\"comment\":\"B停用模板\"}','200',200,14,'2026-09-14 17:31:52'),(175,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":33,\"assetsId\":101,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,18,'2026-09-14 17:31:52'),(176,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":101,\"returnDate\":\"2026-12-31\",\"comment\":\"C拒绝验证\"}','500',200,9,'2026-09-14 17:31:53'),(177,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":,\"assetsId\":101,\"status\":\"拒绝\",\"returnStatus\":\"未归还\"}','500',200,8,'2026-09-14 17:31:53'),(178,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 17:32:43'),(179,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,10,'2026-09-14 17:35:59'),(180,'admin','ADMIN','192.168.200.1','POST','/assetsReceive/add','{\"assetsId\":117,\"returnDate\":\"2026-09-15\"}','200',200,12,'2026-09-14 17:38:52'),(181,'admin','ADMIN','192.168.200.1','PUT','/assetsReceive/update','{\"id\":34,\"assetsId\":117,\"staffId\":4,\"date\":\"2026-09-14 17:38:52\",\"comment\":null,\"returnDate\":\"2026-09-15\",\"status\":\"通过\",\"assetsName\":\"示例笔记本电脑\",\"assetsNo\":\"HM-CAT2026090017\",\"staffName\":null,\"returnStatus\":\"未归还\"}','200',200,20,'2026-09-14 17:38:57'),(182,'admin','ADMIN','192.168.200.1','POST','/robotConfig/add','{\"type\":\"wechat\",\"enabled\":true,\"name\":\"企微资产\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=cc3bc2cd-1282-49d4-baff-808290dfb532\"}','200',200,8,'2026-09-14 17:44:11'),(183,'admin','ADMIN','192.168.200.1','POST','/robotConfig/test/5',NULL,'200',200,394,'2026-09-14 17:44:16'),(184,'admin','ADMIN','192.168.200.1','POST','/assetsIn/add','{\"num\":1,\"date\":\"2026-09-14\",\"acceptDate\":\"2026-09-14\",\"name\":\"11\",\"model\":\"1\",\"money\":\"1\",\"purchaseNo\":\"1\",\"category\":\"打印机\"}','200',200,14,'2026-09-14 17:44:32'),(185,'admin','ADMIN','192.168.200.1','POST','/assetsIn/audit/23','{\"pass\":true,\"rejectReason\":null}','200',200,254,'2026-09-14 17:44:40'),(186,'admin','ADMIN','192.168.200.1','POST','/assetsTransfer/add','{\"assetsId\":118,\"toDepartmentId\":13,\"toStaffId\":null,\"toLocation\":\"11\",\"reason\":\"11\",\"comment\":\"\"}','200',200,14,'2026-09-14 17:44:55'),(187,'admin','ADMIN','192.168.200.1','POST','/assetsTransfer/audit/13','{\"pass\":true}','200',200,401,'2026-09-14 17:45:00'),(188,'admin','ADMIN','192.168.200.1','POST','/assetsReceive/add','{\"assetsId\":118,\"returnDate\":\"2026-09-08\"}','200',200,10,'2026-09-14 17:45:12'),(189,'admin','ADMIN','192.168.200.1','PUT','/assetsReceive/update','{\"id\":35,\"assetsId\":118,\"staffId\":4,\"date\":\"2026-09-14 17:45:12\",\"comment\":null,\"returnDate\":\"2026-09-08\",\"status\":\"通过\",\"assetsName\":\"11\",\"assetsNo\":\"HM-dyj2026090001\",\"staffName\":null,\"returnStatus\":\"未归还\"}','200',200,190,'2026-09-14 17:45:23'),(190,'admin','ADMIN','192.168.200.1','POST','/assetsRepair/add','{\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"reason\":\"1\",\"faultDesc\":\"1\"}','200',200,13,'2026-09-14 17:47:00'),(191,'admin','ADMIN','192.168.200.1','PUT','/assetsRepair/update','{\"id\":22,\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"receiveId\":null,\"status\":\"维修中\",\"reason\":\"1\",\"faultDesc\":\"1\",\"repairResult\":null,\"completeTime\":null,\"date\":\"2026-09-14 17:47:00\",\"staffId\":4,\"staffName\":null}','200',200,426,'2026-09-14 17:47:03'),(192,'admin','ADMIN','192.168.200.1','PUT','/assetsRepair/update','{\"id\":22,\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"receiveId\":null,\"status\":\"已完成\",\"reason\":\"1\",\"faultDesc\":\"1\",\"repairResult\":null,\"completeTime\":null,\"date\":\"2026-09-14 17:47:00\",\"staffId\":4,\"staffName\":null}','200',200,425,'2026-09-14 17:49:23'),(193,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,367,'2026-09-14 17:51:43'),(194,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerPhone\":\"13800000000\",\"returnDate\":\"2026-12-31\"}','500',200,55,'2026-09-14 17:51:43'),(195,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerName\":\"张三\",\"returnDate\":\"2026-12-31\"}','500',200,9,'2026-09-14 17:51:43'),(196,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerName\":\"张三\",\"borrowerPhone\":\"123\",\"returnDate\":\"2026-12-31\"}','500',200,10,'2026-09-14 17:51:43'),(197,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerName\":\"张三\",\"borrowerPhone\":\"13800000001\",\"returnDate\":\"2026-12-31\",\"comment\":\"E2E借用验证\"}','200',200,177,'2026-09-14 17:51:43'),(198,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":108,\"reporterName\":\"赵六\",\"reason\":\"E2E报修验证\",\"faultDesc\":\"x\"}','500',200,13,'2026-09-14 17:51:43'),(199,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":108,\"assetsName\":\"E2E资产\",\"assetsCode\":\"E2E-001\",\"reporterName\":\"赵六\",\"reporterPhone\":\"13600000004\",\"reason\":\"E2E报修验证\",\"faultDesc\":\"键盘失灵\"}','200',200,14,'2026-09-14 17:51:43'),(200,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-tmp\",\"enabled\":true}','200',200,13,'2026-09-14 17:51:43'),(201,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":36,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,770,'2026-09-14 17:51:44'),(202,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,409,'2026-09-14 17:52:33'),(203,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-tmp\",\"enabled\":true}','200',200,202,'2026-09-14 17:52:33'),(204,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerName\":\"钱七\",\"borrowerPhone\":\"13500000005\",\"returnDate\":\"2026-12-31\",\"comment\":\"E2E通知复查\"}','200',200,22,'2026-09-14 17:52:33'),(205,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":38,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,643,'2026-09-14 17:52:34'),(206,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":108,\"assetsName\":\"E2E资产\",\"assetsCode\":\"E2E-002\",\"reporterName\":\"孙八\",\"reporterPhone\":\"13400000006\",\"reason\":\"E2E通知复查报修\",\"faultDesc\":\"风扇异响\"}','200',200,33,'2026-09-14 17:52:35'),(207,'admin','ADMIN','127.0.0.1','PUT','/assetsRepair/update','{\"id\":25,\"status\":\"维修中\"}','200',200,104,'2026-09-14 17:52:35'),(208,'admin','ADMIN','192.168.254.3','POST','/assetsReceive/add','{\"assetsId\":118,\"borrowerName\":\"UI测试\",\"borrowerPhone\":\"13800001111\",\"comment\":\"UI测试\",\"returnDate\":\"2026-12-31\"}','500',200,15,'2026-09-14 17:53:43'),(209,'admin','ADMIN','192.168.254.3','POST','/assetsReceive/add','{\"assetsId\":117,\"borrowerName\":\"UI测试\",\"borrowerPhone\":\"13800001111\",\"comment\":\"UI测试\",\"returnDate\":\"2026-12-31\"}','200',200,12,'2026-09-14 17:53:58'),(210,'admin','ADMIN','192.168.254.3','DELETE','/assetsReceive/delete/39',NULL,'200',200,11,'2026-09-14 17:54:11'),(211,'admin','ADMIN','192.168.254.3','POST','/assetsRepair/add','{\"assetsId\":117,\"assetsName\":\"示例笔记本电脑\",\"assetsCode\":\"HM-CAT2026090017\",\"reason\":\"UI测试\",\"reporterName\":\"UI测试\",\"reporterPhone\":\"13800002222\",\"faultDesc\":\"UI测试\"}','200',200,11,'2026-09-14 17:54:33'),(212,'admin','ADMIN','192.168.254.3','DELETE','/assetsRepair/delete/26',NULL,'200',200,8,'2026-09-14 17:54:45'),(213,'admin','ADMIN','192.168.200.1','POST','/assetsReceive/add','{\"assetsId\":118,\"borrowerName\":\"ly\",\"borrowerPhone\":\"18900200168\",\"returnDate\":\"2026-09-01\"}','500',200,7,'2026-09-14 17:56:09'),(214,'admin','ADMIN','192.168.200.1','POST','/assetsReceive/add','{\"assetsId\":113,\"borrowerName\":\"111\",\"borrowerPhone\":\"18900200168\",\"returnDate\":\"2026-09-16\"}','200',200,13,'2026-09-14 17:56:35'),(215,'admin','ADMIN','192.168.200.1','PUT','/assetsReceive/update','{\"id\":40,\"assetsId\":113,\"staffId\":4,\"borrowerName\":\"111\",\"borrowerPhone\":\"18900200168\",\"date\":\"2026-09-14 17:56:35\",\"comment\":null,\"returnDate\":\"2026-09-16\",\"status\":\"通过\",\"assetsName\":\"示例笔记本电脑\",\"assetsNo\":\"HM-CAT2026090013\",\"staffName\":null,\"returnStatus\":\"未归还\"}','200',200,19,'2026-09-14 17:56:40'),(216,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,463,'2026-09-14 17:59:52'),(217,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerName\":\"归还测试\",\"borrowerPhone\":\"13100000001\",\"returnDate\":\"2026-12-31\",\"comment\":\"E2E归还验证\"}','200',200,176,'2026-09-14 17:59:53'),(218,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":42,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,61,'2026-09-14 17:59:53'),(219,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":42,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"未归还\",\"returnDate\":\"2026-12-31\"}','200',200,28,'2026-09-14 17:59:53'),(220,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":42,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"已归还\"}','200',200,94,'2026-09-14 17:59:53'),(221,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":42,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"已归还\"}','200',200,13,'2026-09-14 17:59:53'),(222,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,411,'2026-09-14 18:00:41'),(223,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":108,\"borrowerName\":\"重启复核\",\"borrowerPhone\":\"13100000009\",\"returnDate\":\"2026-12-31\",\"comment\":\"E2E重启复核\"}','200',200,269,'2026-09-14 18:00:41'),(224,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":43,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"未归还\"}','200',200,87,'2026-09-14 18:00:41'),(225,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":43,\"assetsId\":108,\"status\":\"通过\",\"returnStatus\":\"已归还\"}','200',200,50,'2026-09-14 18:00:41'),(226,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,423,'2026-09-14 20:27:43'),(227,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-submit\",\"enabled\":true}','200',200,248,'2026-09-14 20:27:44'),(228,'admin','ADMIN','127.0.0.1','POST','/assetsIn/add','{\"name\":\"E2E入库资产\",\"category\":\"办公设备\",\"num\":1,\"money\":100,\"purchaseNo\":\"E2E-IN-SUB\"}','200',200,112,'2026-09-14 20:27:45'),(229,'admin','ADMIN','127.0.0.1','POST','/assetsTransfer/add','{\"assetsId\":108,\"toDepartmentId\":,\"toLocation\":\"E2E新地点\",\"reason\":\"E2E调拨提交\"}','500',200,50,'2026-09-14 20:27:45'),(230,'admin','ADMIN','127.0.0.1','POST','/assetsScrap/add','{\"assetsId\":108,\"scrapType\":\"正常报废\",\"reason\":\"E2E报废提交\"}','200',200,120,'2026-09-14 20:27:45'),(231,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-14 20:28:03'),(232,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-tr\",\"enabled\":true}','200',200,9,'2026-09-14 20:28:03'),(233,'admin','ADMIN','127.0.0.1','POST','/assetsTransfer/add','{\"assetsId\":26,\"toDepartmentId\":12,\"toLocation\":\"E2E新地点\",\"reason\":\"E2E调拨提交\"}','200',200,143,'2026-09-14 20:28:03'),(234,'admin','ADMIN','192.168.200.1','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,409,'2026-09-14 20:33:55'),(235,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,7,'2026-09-14 20:34:00'),(236,'admin','ADMIN','127.0.0.1','POST','/robotConfig/add','{\"name\":\"E2E临时\",\"type\":\"wechat\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=e2e-batch\",\"enabled\":true}','200',200,74,'2026-09-14 20:34:00'),(237,'admin','ADMIN','127.0.0.1','POST','/assetsIn/import',NULL,'200',200,1514,'2026-09-14 20:34:02'),(238,'admin','ADMIN','192.168.200.1','PUT','/assetsRepair/update','{\"id\":29,\"assetsId\":118,\"assetsName\":\"11\",\"assetsCode\":\"HM-dyj2026090001\",\"receiveId\":null,\"status\":\"维修中\",\"reason\":\"1\",\"faultDesc\":\"1\",\"repairResult\":null,\"completeTime\":null,\"date\":\"2026-09-14 20:34:54\",\"staffId\":null,\"reporterName\":\"11\",\"reporterPhone\":\"18888888888\",\"staffName\":null}','200',200,22,'2026-09-14 20:36:09'),(239,'admin','ADMIN','192.168.200.1','POST','/robotConfig/add','{\"type\":\"wechat\",\"enabled\":true,\"name\":\"资产提醒\",\"webhookUrl\":\"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=cc3bc2cd-1282-49d4-baff-808290dfb532\"}','200',200,11,'2026-09-14 20:36:48'),(240,'admin','ADMIN','192.168.200.1','PUT','/assetsReceive/update','{\"id\":35,\"assetsId\":118,\"status\":\"通过\",\"returnStatus\":\"已归还\"}','200',200,16,'2026-09-14 20:39:58'),(241,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,393,'2026-09-14 20:42:44'),(242,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":26,\"reporterName\":\"照片测试\",\"reporterPhone\":\"13100000021\"}','500',200,62,'2026-09-14 20:42:44'),(243,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":26,\"assetsName\":\"E2E资产\",\"assetsCode\":\"E2E-PIC\",\"reporterName\":\"照片测试\",\"reporterPhone\":\"13100000021\",\"faultDesc\":\"E2E合并字段描述\",\"img\":\"/files/1789389764285-e2e_photo.png\"}','200',200,741,'2026-09-14 20:42:45'),(244,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-14 20:43:43'),(245,'admin','ADMIN','127.0.0.1','POST','/robotConfig/test/13',NULL,'200',200,395,'2026-09-14 20:43:43'),(246,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,103,'2026-09-14 21:00:08'),(247,'admin','ADMIN','192.168.200.1','PUT','/assets/update','{\"id\":118,\"name\":\"11\",\"category\":\"打印机\",\"no\":\"HM-dyj2026090001\",\"img\":null,\"model\":\"1\",\"num\":1,\"date\":\"2026-09-14\",\"money\":1,\"currentValue\":0,\"depreciate\":null,\"depreciationRate\":0,\"departmentId\":13,\"departmentName\":\"11\",\"staffId\":null,\"staffName\":null,\"location\":\"11111\",\"status\":\"正常\",\"comment\":\"采购单号:1\",\"dateStart\":null,\"dateEnd\":null}','200',200,66,'2026-09-14 21:00:25'),(248,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,25,'2026-09-14 21:01:58'),(249,'admin','ADMIN','127.0.0.1','POST','/department/import',NULL,'200',200,883,'2026-09-14 21:01:59'),(250,'admin','ADMIN','127.0.0.1','POST','/department/import',NULL,'200',200,29,'2026-09-14 21:01:59'),(251,'admin','ADMIN','127.0.0.1','POST','/department/import',NULL,'500',200,23,'2026-09-14 21:01:59'),(252,'admin','ADMIN','127.0.0.1','POST','/assetsIn/add','{\"name\":\"测试打印机13\",\"category\":\"办公设备\",\"model\":\"TP-13\",\"num\":3,\"money\":1000,\"purchaseNo\":\"TEST13\",\"supplier\":\"测试供应商\",\"location\":\"测试仓库\",\"date\":\"2026-09-14\"}','200',200,5952,'2026-09-14 21:02:05'),(253,'admin','ADMIN','127.0.0.1','POST','/assetsIn/audit/28','{\"pass\":true}','200',200,206,'2026-09-14 21:02:05'),(254,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":119,\"borrowerName\":\"测试借用人\",\"borrowerPhone\":\"13800000000\",\"returnDate\":\"2026-09-13\",\"comment\":\"到期提醒测试\"}','200',200,153,'2026-09-14 21:02:05'),(255,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":120,\"borrowerName\":\"测试借用人\",\"borrowerPhone\":\"13800000000\",\"returnDate\":\"2026-09-14\",\"comment\":\"到期提醒测试\"}','200',200,154,'2026-09-14 21:02:06'),(256,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":121,\"borrowerName\":\"测试借用人\",\"borrowerPhone\":\"13800000000\",\"returnDate\":\"2026-09-15\",\"comment\":\"到期提醒测试\"}','200',200,141,'2026-09-14 21:02:06'),(257,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":46,\"status\":\"通过\"}','200',200,162,'2026-09-14 21:02:06'),(258,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":47,\"status\":\"通过\"}','200',200,152,'2026-09-14 21:02:06'),(259,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":48,\"status\":\"通过\"}','200',200,160,'2026-09-14 21:02:06'),(260,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":46,\"status\":\"通过\"}','200',200,10,'2026-09-14 21:02:06'),(261,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":48,\"assetsId\":121,\"status\":\"通过\",\"returnStatus\":\"已归还\"}','200',200,14,'2026-09-14 21:02:06'),(262,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":48,\"assetsId\":121,\"status\":\"通过\",\"returnStatus\":\"已归还\"}','200',200,10,'2026-09-14 21:02:06'),(263,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,102,'2026-09-14 21:05:32'),(264,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,3,'2026-09-14 21:07:03'),(265,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,106,'2026-09-14 21:07:10'),(266,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,101,'2026-09-14 21:09:59'),(267,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,100,'2026-09-14 21:10:16'),(268,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,114,'2026-09-14 21:12:48'),(269,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,150,'2026-09-14 21:14:41'),(270,'admin','ADMIN','192.168.254.3','POST','/company/add','{\"sort\":1,\"name\":\"测试公司UI\",\"remark\":\"自动化验证\"}','200',200,83,'2026-09-14 21:15:02'),(271,'admin','ADMIN','192.168.254.3','POST','/company/add','{\"sort\":0,\"name\":\"测试公司UI\"}','500',200,10,'2026-09-14 21:15:24'),(272,'admin','ADMIN','192.168.254.3','POST','/company/add','{\"sort\":0,\"name\":\"测试公司UI\"}','500',200,9,'2026-09-14 21:15:54'),(273,'admin','ADMIN','192.168.254.3','PUT','/company/update','{\"id\":3,\"name\":\"测试公司UI\",\"sort\":1,\"remark\":\"自动化验证-已改\",\"createTime\":\"2026-09-14 21:15:02\",\"updateTime\":\"2026-09-14 21:15:02\"}','200',200,15,'2026-09-14 21:16:09'),(274,'admin','ADMIN','192.168.254.3','POST','/department/add','{\"level\":1,\"companyId\":3,\"name\":\"测试部门UI\"}','200',200,15,'2026-09-14 21:16:44'),(275,'admin','ADMIN','192.168.254.3','DELETE','/department/delete/17',NULL,'200',200,13,'2026-09-14 21:19:21'),(276,'admin','ADMIN','192.168.254.3','DELETE','/company/delete/3',NULL,'200',200,72,'2026-09-14 21:19:40'),(277,'admin','ADMIN','192.168.200.1','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,6,'2026-09-16 09:48:40'),(278,'admin','ADMIN','192.168.200.1','POST','/company/add','{\"sort\":0,\"name\":\"赫玛科技\"}','200',200,8,'2026-09-16 09:49:27'),(279,'admin','ADMIN','192.168.200.1','POST','/company/add','{\"sort\":1,\"name\":\"堡格丽\"}','200',200,8,'2026-09-16 09:49:45'),(280,'admin','ADMIN','192.168.200.1','POST','/company/add','{\"sort\":2,\"name\":\"和晋智能\"}','200',200,11,'2026-09-16 09:49:58'),(281,'admin','ADMIN','192.168.200.1','DELETE','/department/delete/12',NULL,'200',200,8,'2026-09-16 09:50:05'),(282,'admin','ADMIN','192.168.200.1','DELETE','/department/delete/13',NULL,'200',200,7,'2026-09-16 09:50:06'),(283,'admin','ADMIN','192.168.200.1','POST','/department/import',NULL,'200',200,296,'2026-09-16 10:02:10'),(284,'admin','ADMIN','192.168.200.1','DELETE','/assets/delete/batch','[118,117,116,115,114,113,112,111,110,109]','200',200,19,'2026-09-16 10:02:22'),(285,'admin','ADMIN','192.168.200.1','DELETE','/assets/delete/batch','[108,107,106,105,104,103,102,101,100,32]','200',200,22,'2026-09-16 10:02:25'),(286,'admin','ADMIN','192.168.200.1','DELETE','/assets/delete/batch','[27,26]','200',200,9,'2026-09-16 10:02:29'),(287,'admin','ADMIN','192.168.200.1','DELETE','/assetsIn/delete/batch','[23,22,21,20,19,18,17,16,15,14]','200',200,21,'2026-09-16 10:02:38'),(288,'admin','ADMIN','192.168.200.1','DELETE','/assetsTransfer/delete/batch','[13,12,11]','200',200,74,'2026-09-16 10:02:42'),(289,'unknown',NULL,'127.0.0.1','DELETE','/assetsReceive/delete/999901',NULL,'401',200,2,'2026-09-16 10:04:05'),(290,'unknown',NULL,'127.0.0.1','DELETE','/assetsRepair/delete/999901',NULL,'401',200,1,'2026-09-16 10:04:05'),(291,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-16 10:04:19'),(292,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/999901',NULL,'200',200,6,'2026-09-16 10:04:19'),(293,'admin','ADMIN','127.0.0.1','DELETE','/assetsRepair/delete/999901',NULL,'200',200,5,'2026-09-16 10:04:19'),(294,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,103,'2026-09-16 10:06:29'),(295,'admin','ADMIN','192.168.200.1','DELETE','/category/delete/batch','[15,14,13]','200',200,39,'2026-09-16 10:06:55'),(296,'admin','ADMIN','192.168.200.1','DELETE','/notice/delete/batch','[6,5]','200',200,11,'2026-09-16 10:07:27'),(297,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,45,'2026-09-16 10:07:44'),(298,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":,\"borrowerName\":\"测试删除\",\"borrowerPhone\":\"13800000001\",\"returnDate\":\"2026-09-16\",\"comment\":\"删除修复验证\"}','500',200,11,'2026-09-16 10:07:44'),(299,'admin','ADMIN','127.0.0.1','PUT','/assetsReceive/update','{\"id\":,\"status\":\"通过\"}','500',200,8,'2026-09-16 10:07:44'),(300,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/',NULL,NULL,404,11,'2026-09-16 10:07:44'),(301,'admin','ADMIN','127.0.0.1','POST','/assetsReceive/add','{\"assetsId\":,\"borrowerName\":\"测试删除\",\"borrowerPhone\":\"13800000001\",\"returnDate\":\"2026-09-16\",\"comment\":\"待审核删除\"}','500',200,9,'2026-09-16 10:07:44'),(302,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/',NULL,NULL,404,7,'2026-09-16 10:07:44'),(303,'admin','ADMIN','127.0.0.1','POST','/assetsRepair/add','{\"assetsId\":,\"reporterName\":\"测试删除\",\"reporterPhone\":\"13800000001\",\"faultDesc\":\"删除修复验证\"}','500',200,15,'2026-09-16 10:07:44'),(304,'admin','ADMIN','127.0.0.1','DELETE','/assetsRepair/delete/',NULL,NULL,404,8,'2026-09-16 10:07:44'),(305,'admin','ADMIN','192.168.200.1','POST','/admin/add','{\"roleId\":2,\"username\":\"吴津霞\",\"name\":\"吴津霞\"}','200',200,18,'2026-09-16 10:08:18'),(306,'admin','ADMIN','192.168.200.1','POST','/role/assignMenus','{\"roleId\":2,\"menuIds\":[1,11,12,13,14,15,16,17,21,22,55,10,20]}','200',200,34,'2026-09-16 10:08:56'),(307,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-09-16 10:09:22'),(308,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/49',NULL,'200',200,17,'2026-09-16 10:09:22'),(309,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/50',NULL,'200',200,9,'2026-09-16 10:09:22'),(310,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/51',NULL,'200',200,11,'2026-09-16 10:09:22'),(311,'admin','ADMIN','127.0.0.1','DELETE','/assetsRepair/delete/32',NULL,'200',200,8,'2026-09-16 10:09:22'),(312,'admin','ADMIN','127.0.0.1','DELETE','/assetsRepair/delete/33',NULL,'200',200,11,'2026-09-16 10:09:22'),(313,'admin','ADMIN','127.0.0.1','DELETE','/assetsReceive/delete/batch','[52,53]','200',200,16,'2026-09-16 10:09:23'),(314,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-16 10:10:01'),(315,'admin','ADMIN','192.168.200.1','DELETE','/assetsRepair/delete/29',NULL,'200',200,11,'2026-09-16 10:35:01'),(316,'admin','ADMIN','192.168.200.1','DELETE','/assetsRepair/delete/27',NULL,'200',200,9,'2026-09-16 10:35:02'),(317,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-09-16 10:35:04'),(318,'admin','ADMIN','192.168.200.1','DELETE','/assetsRepair/delete/22',NULL,'200',200,6,'2026-09-16 10:35:04'),(319,'admin','ADMIN','192.168.200.1','DELETE','/assetsRepair/delete/21',NULL,'200',200,6,'2026-09-16 10:35:06'),(320,'admin','ADMIN','192.168.200.1','DELETE','/assetsReceive/delete/45',NULL,'200',200,8,'2026-09-16 10:35:10'),(321,'admin','ADMIN','192.168.200.1','DELETE','/assetsReceive/delete/41',NULL,'200',200,8,'2026-09-16 10:35:11'),(322,'admin','ADMIN','192.168.200.1','DELETE','/assetsReceive/delete/40',NULL,'200',200,8,'2026-09-16 10:35:13'),(323,'admin','ADMIN','192.168.200.1','DELETE','/assetsReceive/delete/35',NULL,'200',200,7,'2026-09-16 10:35:14'),(324,'admin','ADMIN','192.168.200.1','DELETE','/assetsReceive/delete/34',NULL,'200',200,8,'2026-09-16 10:35:17'),(325,'admin','ADMIN','192.168.200.1','DELETE','/assetsReceive/delete/29',NULL,'200',200,9,'2026-09-16 10:35:19'),(326,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,97,'2026-09-16 10:44:41'),(327,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,146,'2026-09-16 10:46:17'),(328,'admin','ADMIN','127.0.0.1','POST','/staff/import',NULL,'200',200,286,'2026-09-16 10:46:18'),(329,'admin','ADMIN','127.0.0.1','POST','/staff/import',NULL,'200',200,38,'2026-09-16 10:46:18'),(330,'admin','ADMIN','127.0.0.1','PUT','/staff/leave/26',NULL,'200',200,28,'2026-09-16 10:46:18'),(331,'admin','ADMIN','127.0.0.1','PUT','/staff/leave/26',NULL,'400',200,12,'2026-09-16 10:46:18'),(332,'admin','ADMIN','127.0.0.1','PUT','/staff/leave/batch','[26,27]','200',200,15,'2026-09-16 10:46:18'),(333,'admin','ADMIN','127.0.0.1','POST','/assets/add','{\"name\":\"测试离职标志资产\",\"category\":\"测试分类\",\"no\":\"ZZTEST-14\",\"num\":1,\"date\":\"2026-09-16\",\"status\":\"正常\",\"staffId\":26,\"location\":\"测试\"}','200',200,19,'2026-09-16 10:46:18'),(334,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-09-16 10:46:42'),(335,'admin','ADMIN','127.0.0.1','POST','/staff/add','{\"username\":\"zzmark_a\",\"name\":\"离职标志甲\",\"password\":\"***\",\"status\":\"在职\"}','200',200,15,'2026-09-16 10:46:42'),(336,'admin','ADMIN','127.0.0.1','POST','/assets/add','{\"name\":\"ZZMARKASSET\",\"category\":\"测试\",\"no\":\"ZZMARK-1\",\"num\":1,\"date\":\"2026-09-16\",\"status\":\"正常\",\"staffId\":28,\"location\":\"测试\"}','200',200,8,'2026-09-16 10:46:43'),(337,'admin','ADMIN','127.0.0.1','PUT','/staff/leave/28',NULL,'200',200,12,'2026-09-16 10:46:43'),(338,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,11,'2026-09-16 10:47:09'),(339,'admin','ADMIN','192.168.254.3','POST','/staff/add','{\"status\":\"在职\",\"username\":\"zzui_test\",\"name\":\"界面验证员工\"}','200',200,73,'2026-09-16 10:48:50'),(340,'admin','ADMIN','192.168.254.3','PUT','/staff/leave/29',NULL,'200',200,10,'2026-09-16 10:49:07'),(341,'admin','ADMIN','192.168.254.3','POST','/staff/add','{\"status\":\"在职\",\"username\":\"zzui_test2\",\"name\":\"界面验证员工2\"}','200',200,11,'2026-09-16 10:49:21'),(342,'admin','ADMIN','192.168.254.3','PUT','/staff/leave/batch','[30]','200',200,10,'2026-09-16 10:57:11'),(343,'admin','ADMIN','192.168.254.3','DELETE','/staff/delete/30',NULL,'200',200,10,'2026-09-16 10:57:37'),(344,'admin','ADMIN','192.168.254.3','DELETE','/staff/delete/29',NULL,'200',200,13,'2026-09-16 10:57:46'),(345,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,109,'2026-09-17 11:53:47'),(346,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,174,'2026-09-17 11:55:01'),(347,'admin','ADMIN','127.0.0.1','POST','/staff/import',NULL,'200',200,346,'2026-09-17 11:55:03'),(348,'admin','ADMIN','192.168.200.1','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,14,'2026-09-18 19:54:56'),(349,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,5,'2026-09-20 16:00:03'),(350,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,5,'2026-09-24 16:43:49'),(351,'admin','ADMIN','192.168.20.253','POST','/category/add','{\"name\":\"笔记本电脑\",\"code\":\"DZ01\"}','200',200,15,'2026-09-24 16:49:51'),(352,'admin','ADMIN','192.168.20.253','POST','/assets/add','{\"num\":1,\"name\":\"华硕笔记本电脑\",\"category\":\"笔记本电脑\",\"no\":\"HM-DZ012026090001\"}','200',200,20,'2026-09-24 16:50:34'),(353,'admin','ADMIN','192.168.20.253','POST','/staff/add','{\"status\":\"在职\",\"username\":\"孙纪猛\",\"name\":\"孙纪猛\",\"departmentId\":37}','200',200,13,'2026-09-24 16:52:34'),(354,'admin','ADMIN','192.168.20.253','PUT','/assets/update','{\"id\":125,\"name\":\"华硕笔记本电脑\",\"category\":\"笔记本电脑\",\"no\":\"HM-DZ012026090001\",\"img\":null,\"model\":\"华硕无畏14\",\"num\":1,\"date\":null,\"money\":null,\"currentValue\":0,\"depreciate\":null,\"depreciationRate\":0,\"departmentId\":37,\"departmentName\":null,\"staffId\":34,\"staffName\":null,\"location\":\"36栋\",\"status\":\"正常\",\"comment\":null,\"dateStart\":null,\"dateEnd\":null}','200',200,9,'2026-09-24 16:53:10'),(355,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-09-28 18:20:39'),(356,'unknown',NULL,'206.81.24.74','POST','/graphql',NULL,NULL,200,1,'2026-10-03 22:29:21'),(357,'unknown',NULL,'206.81.24.74','POST','/gql',NULL,NULL,200,1,'2026-10-03 22:29:22'),(358,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,5,'2026-10-14 14:25:11'),(359,'admin','ADMIN','192.168.20.253','POST','/staff/add','{\"status\":\"在职\",\"departmentId\":40,\"username\":\"林燕\",\"name\":\"林燕\"}','200',200,11,'2026-10-14 14:25:57'),(360,'admin','ADMIN','192.168.20.253','POST','/assetsIn/add','{\"num\":1,\"date\":\"2026-10-14\",\"acceptDate\":\"2026-10-14\",\"name\":\"笔记本电脑\",\"category\":\"笔记本电脑\"}','200',200,918,'2026-10-14 14:26:14'),(361,'admin','ADMIN','192.168.20.253','POST','/assetsIn/audit/29','{\"pass\":true,\"rejectReason\":null}','200',200,181,'2026-10-14 14:26:18'),(362,'孙纪猛','STAFF','192.168.20.253','POST','/login','{\"role\":\"STAFF\",\"username\":\"孙纪猛\",\"password\":\"***\"}','200',200,4,'2026-10-15 15:45:43'),(363,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,2,'2026-10-15 15:51:17'),(364,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,3,'2026-10-15 15:55:19'),(365,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,98,'2026-10-15 16:00:56'),(366,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,146,'2026-10-15 16:02:17'),(367,'admin','ADMIN','127.0.0.1','POST','/department/add','{\"name\":\"ZZ清理验证部\",\"companyId\":4,\"level\":1}','200',200,18,'2026-10-15 16:02:17'),(368,'admin','ADMIN','127.0.0.1','PUT','/department/update','{\"id\":42,\"name\":\"ZZ清理验证部2\",\"address\":\"测试地址\"}','200',200,11,'2026-10-15 16:02:17'),(369,'admin','ADMIN','127.0.0.1','POST','/staff/add','{\"username\":\"zzclean_a\",\"name\":\"清理验证员工\",\"password\":\"***\",\"status\":\"在职\",\"departmentId\":42,\"phone\":\"13800001234\"}','200',200,37,'2026-10-15 16:02:17'),(370,'admin','ADMIN','127.0.0.1','PUT','/staff/update','{\"id\":36,\"position\":\"测试岗位\"}','200',200,14,'2026-10-15 16:02:17'),(371,'admin','ADMIN','127.0.0.1','PUT','/staff/leave/36',NULL,'200',200,20,'2026-10-15 16:02:18'),(372,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-10-15 16:02:43'),(373,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,10,'2026-10-15 16:03:02'),(374,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-10-15 16:05:33'),(375,'admin','ADMIN','127.0.0.1','POST','/staff/add','{\"username\":\"zzdrop_a\",\"name\":\"DROP验证员工\",\"password\":\"***\",\"status\":\"在职\",\"phone\":\"13800002222\"}','200',200,10,'2026-10-15 16:05:33'),(376,'admin','ADMIN','127.0.0.1','PUT','/staff/update','{\"id\":37,\"position\":\"DROP验证岗位\"}','200',200,9,'2026-10-15 16:05:33'),(377,'admin','ADMIN','127.0.0.1','PUT','/staff/leave/37',NULL,'200',200,9,'2026-10-15 16:05:33'),(378,'admin','ADMIN','127.0.0.1','POST','/department/add','{\"name\":\"ZZDROP验证部\",\"companyId\":4,\"level\":1}','200',200,8,'2026-10-15 16:05:33'),(379,'admin','ADMIN','127.0.0.1','PUT','/department/update','{\"id\":43,\"address\":\"DROP验证地址\"}','200',200,10,'2026-10-15 16:05:33'),(380,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,3,'2026-10-15 16:07:19'),(381,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-10-15 16:07:44'),(382,'admin','ADMIN','127.0.0.1','POST','/staff/import',NULL,'200',200,123,'2026-10-15 16:07:45'),(383,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,94,'2026-10-15 16:13:38'),(384,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,113,'2026-10-15 16:15:14'),(385,'admin','ADMIN','127.0.0.1','PUT','/sysConfig/save','[  {\"configKey\":\"system_name\",\"configValue\":\"赫玛资产管理系统\"},  {\"configKey\":\"browser_title\",\"configValue\":\"赫玛资产-页面设置验证\"},  {\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎来到赫玛科技\"},  {\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052115057-testbg.png\"},  {\"configKey\":\"logo\",\"configValue\":\"/files/1792052115122-testlogo.png\"},  {\"configKey\":\"footer_text\",\"configValue\":\"© 2026 赫玛科技 版权所有\"},  {\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛资产管理系统\"}]','200',200,84,'2026-10-15 16:15:15'),(386,'admin','ADMIN','127.0.0.1','PUT','/sysConfig/save','[{\"configKey\":\"hack_key\",\"configValue\":\"x\"}]','500',200,10,'2026-10-15 16:15:15'),(387,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,12,'2026-10-15 16:16:12'),(388,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-10-15 16:17:41'),(389,'admin','ADMIN','127.0.0.1','PUT','/sysConfig/save','[  {\"configKey\":\"system_name\",\"configValue\":\"固定资产管理系统\"},  {\"configKey\":\"browser_title\",\"configValue\":\"固定资产管理系统\"},  {\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},  {\"configKey\":\"login_bg\",\"configValue\":\"\"},  {\"configKey\":\"logo\",\"configValue\":\"\"},  {\"configKey\":\"footer_text\",\"configValue\":\"\"},  {\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用固定资产管理系统\"}]','200',200,56,'2026-10-15 16:17:41'),(390,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,5,'2026-10-15 16:26:28'),(391,'admin','ADMIN','192.168.20.253','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"}]','200',200,21,'2026-10-15 16:28:07'),(392,'cs','STAFF','192.168.20.253','POST','/register','{\"role\":\"STAFF\",\"username\":\"cs\",\"password\":\"***\",\"confirmPass\":\"123\"}','200',200,14,'2026-10-15 16:29:15'),(393,'cs','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"cs\",\"password\":\"***\"}','5004',200,4,'2026-10-15 16:29:25'),(394,'cs','STAFF','192.168.20.253','POST','/login','{\"role\":\"STAFF\",\"username\":\"cs\",\"password\":\"***\"}','200',200,5,'2026-10-15 16:29:33'),(395,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-10-15 16:31:10'),(396,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,107,'2026-10-15 16:32:49'),(397,'unknown',NULL,'127.0.0.1','POST','/register',NULL,NULL,200,14,'2026-10-15 16:32:49'),(398,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,103,'2026-10-15 16:34:49'),(399,'unknown',NULL,'127.0.0.1','POST','/register',NULL,NULL,200,10,'2026-10-15 16:34:50'),(400,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,3,'2026-10-15 16:34:50'),(401,'unknown',NULL,'127.0.0.1','POST','/register',NULL,NULL,200,20,'2026-10-15 16:37:19'),(402,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,11,'2026-10-15 16:37:19'),(403,'unknown',NULL,'127.0.0.1','POST','/register',NULL,NULL,404,18,'2026-10-15 16:42:22'),(404,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,14,'2026-10-15 16:42:22'),(405,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,110,'2026-10-15 16:45:24'),(406,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,6,'2026-10-15 16:45:31'),(407,'unknown',NULL,'127.0.0.1','POST','/login',NULL,'500',200,101,'2026-10-15 18:32:34'),(408,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,147,'2026-10-15 18:33:49'),(409,'孙纪猛','STAFF','127.0.0.1','POST','/login','{\"username\":\"孙纪猛\",\"password\":\"***\",\"role\":\"STAFF\"}','200',200,29,'2026-10-15 18:33:49'),(410,'unknown',NULL,'127.0.0.1','POST','/scan/updateAsset','{\"id\":125,\"name\":\"员工恶意改名\",\"status\":\"报废\",\"location\":\"员工改的\",\"comment\":\"员工改的\"}','403',200,12,'2026-10-15 18:33:49'),(413,'admin','ADMIN','127.0.0.1','POST','/scan/updateAsset','{\"id\":125,\"name\":\"   \",\"status\":\"正常\"}','500',200,5,'2026-10-15 18:33:49'),(414,'admin','ADMIN','127.0.0.1','POST','/scan/updateAsset','{\"name\":\"x\"}','500',200,5,'2026-10-15 18:33:49'),(415,'admin','ADMIN','127.0.0.1','POST','/scan/updateAsset','{\"id\":999999,\"name\":\"x\"}','404',200,7,'2026-10-15 18:33:49'),(416,'unknown',NULL,'127.0.0.1','POST','/scan/borrow','{\"assetsId\":125,\"borrowerName\":\"ZZSCAN匿名验证\",\"borrowerPhone\":\"13800009999\",\"returnDate\":\"2026-12-31\",\"comment\":\"自动验证后清理\"}','200',200,787,'2026-10-15 18:33:50'),(417,'unknown',NULL,'127.0.0.1','POST','/scan/repair','{\"assetsId\":125,\"reporterName\":\"ZZSCAN匿名验证\",\"reporterPhone\":\"13800009999\",\"faultDesc\":\"自动验证后清理\"}','200',200,173,'2026-10-15 18:33:50'),(418,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,11,'2026-10-15 18:36:04'),(419,'admin','ADMIN','192.168.254.3','POST','/scan/updateAsset','{\"id\":125,\"name\":\"华硕笔记本电脑\",\"status\":\"正常\",\"location\":\"36栋\",\"staffId\":34,\"comment\":\"\",\"img\":null}','200',200,9,'2026-10-15 18:36:37'),(420,'admin','ADMIN','192.168.254.3','POST','/scan/updateAsset','{\"id\":125,\"name\":\"华硕笔记本电脑\",\"status\":\"正常\",\"location\":\"36栋\",\"staffId\":34,\"comment\":\"\",\"img\":null}','200',200,8,'2026-10-15 18:36:54'),(421,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,106,'2026-10-17 10:02:55'),(422,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','5003',200,5,'2026-10-17 10:08:54'),(423,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','5003',200,4,'2026-10-17 10:09:03'),(424,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,116,'2026-10-17 10:10:22'),(425,'admin','ADMIN','192.168.254.3','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"},{\"configKey\":\"scan_fields\",\"configValue\":\"no,category,model,status,date,money,departmentName,staffName,location,comment,img,num,depreciate\"}]','200',200,100,'2026-10-17 10:11:28'),(426,'admin','ADMIN','192.168.254.3','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"},{\"configKey\":\"scan_fields\",\"configValue\":\"no,category,model,status,date,money,departmentName,staffName,location,comment,img\"}]','200',200,27,'2026-10-17 10:11:51'),(427,'admin','ADMIN','192.168.254.3','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"},{\"configKey\":\"scan_fields\",\"configValue\":\"no,category,model,status,date,money,departmentName,staffName,location,comment,img\"},{\"configKey\":\"scan_title\",\"configValue\":\"设备信息\"},{\"configKey\":\"scan_footer\",\"configValue\":\"赫玛科技资产平台\"},{\"configKey\":\"scan_borrow_text\",\"configValue\":\"我要借用\"},{\"configKey\":\"scan_repair_text\",\"configValue\":\"我要报修\"}]','200',200,154,'2026-10-17 10:18:40'),(428,'admin','ADMIN','192.168.254.3','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"},{\"configKey\":\"scan_fields\",\"configValue\":\"no,category,model,status,date,money,departmentName,staffName,location,comment,img\"},{\"configKey\":\"scan_title\",\"configValue\":\"资产信息\"},{\"configKey\":\"scan_footer\",\"configValue\":\"固定资产管理系统\"},{\"configKey\":\"scan_borrow_text\",\"configValue\":\"申请借用\"},{\"configKey\":\"scan_repair_text\",\"configValue\":\"申请报修\"}]','200',200,39,'2026-10-17 10:18:57'),(429,'admin','ADMIN','192.168.20.253','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"},{\"configKey\":\"scan_fields\",\"configValue\":\"no,category,model,status,date,money,departmentName,staffName,location,comment,img\"},{\"configKey\":\"scan_title\",\"configValue\":\"赫玛集团资产卡片\"},{\"configKey\":\"scan_footer\",\"configValue\":\"赫玛集团2026\"},{\"configKey\":\"scan_borrow_text\",\"configValue\":\"临时借用\"},{\"configKey\":\"scan_repair_text\",\"configValue\":\"故障反馈\"}]','200',200,44,'2026-10-17 10:22:52'),(430,'admin','ADMIN','192.168.20.253','PUT','/sysConfig/save','[{\"configKey\":\"system_name\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"browser_title\",\"configValue\":\"赫玛集团-固资系统\"},{\"configKey\":\"login_subtitle\",\"configValue\":\"欢迎使用\"},{\"configKey\":\"login_bg\",\"configValue\":\"/files/1792052802911-1111.jpg\"},{\"configKey\":\"logo\",\"configValue\":\"/files/1792052821518-微信图片_20251128154530_195_1705.png\"},{\"configKey\":\"footer_text\",\"configValue\":\"2026赫玛科技版权所有\"},{\"configKey\":\"dashboard_welcome\",\"configValue\":\"欢迎使用赫玛集团固定资产管理系统\"},{\"configKey\":\"scan_fields\",\"configValue\":\"no,category,model,status,date,money,departmentName,staffName,location,comment,img\"},{\"configKey\":\"scan_title\",\"configValue\":\"资产卡片\"},{\"configKey\":\"scan_footer\",\"configValue\":\"赫玛集团2026\"},{\"configKey\":\"scan_borrow_text\",\"configValue\":\"临时借用\"},{\"configKey\":\"scan_repair_text\",\"configValue\":\"故障反馈\"}]','200',200,30,'2026-10-17 10:23:42'),(431,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,121,'2026-10-17 11:04:24'),(432,'admin','ADMIN','192.168.254.3','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,11,'2026-10-17 11:07:38'),(433,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,4,'2026-10-17 11:15:51'),(434,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,482,'2026-10-17 11:23:12'),(435,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-10-17 11:23:34'),(436,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,6,'2026-10-17 11:23:49'),(437,'admin','ADMIN','192.168.20.253','POST','/login','{\"role\":\"ADMIN\",\"username\":\"admin\",\"password\":\"***\"}','200',200,12,'2026-10-17 11:45:30'),(438,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,116,'2026-10-17 11:52:51'),(439,'admin','ADMIN','127.0.0.1','PUT','/assetField/save','[{\"id\": 1, \"fieldKey\": \"no\", \"label\": \"设备编号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 10, \"updateTime\": null}, {\"id\": 2, \"fieldKey\": \"name\", \"label\": \"设备名称\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 20, \"updateTime\": null}, {\"id\": 3, \"fieldKey\": \"category\", \"label\": \"资产分类\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 30, \"updateTime\": null}, {\"id\": 4, \"fieldKey\": \"img\", \"label\": \"资产图片\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 40, \"updateTime\": null}, {\"id\": 5, \"fieldKey\": \"model\", \"label\": \"资产型号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 50, \"updateTime\": null}, {\"id\": 6, \"fieldKey\": \"num\", \"label\": \"数量\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 60, \"updateTime\": null}, {\"id\": 7, \"fieldKey\": \"date\", \"label\": \"购置日期\", \"fieldType\": \"date\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 70, \"updateTime\": null}, {\"id\": 8, \"fieldKey\": \"money\", \"label\": \"初始价值\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 80, \"updateTime\": null}, {\"id\": 9, \"fieldKey\": \"depreciate\", \"label\": \"折旧方法\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 90, \"updateTime\": null}, {\"id\": 10, \"fieldKey\": \"companyName\", \"label\": \"所属公司\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 100, \"updateTime\": null}, {\"id\": 11, \"fieldKey\": \"departmentName\", \"label\": \"所属部门\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 110, \"updateTime\": null}, {\"id\": 12, \"fieldKey\": \"staffName\", \"label\": \"责任人\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 120, \"updateTime\": null}, {\"id\": 13, \"fieldKey\": \"location\", \"label\": \"存放地点\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 130, \"updateTime\": null}, {\"id\":','200',200,328,'2026-10-17 11:52:51'),(440,'admin','ADMIN','127.0.0.1','PUT','/assets/update','{\"id\":125,\"custom1\":\"2027-12-31\",\"custom2\":\"高\"}','200',200,21,'2026-10-17 11:52:51'),(441,'admin','ADMIN','127.0.0.1','POST','/assets/import',NULL,'200',200,101,'2026-10-17 11:52:52'),(442,'admin','ADMIN','127.0.0.1','PUT','/assetField/save','[{\"id\": 1, \"fieldKey\": \"no\", \"label\": \"资产编号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 10, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 2, \"fieldKey\": \"name\", \"label\": \"资产名称\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 20, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 3, \"fieldKey\": \"category\", \"label\": \"资产分类\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 30, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 4, \"fieldKey\": \"img\", \"label\": \"资产图片\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 40, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 5, \"fieldKey\": \"model\", \"label\": \"资产型号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 50, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 6, \"fieldKey\": \"num\", \"label\": \"数量\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 60, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 7, \"fieldKey\": \"date\", \"label\": \"购置日期\", \"fieldType\": \"date\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 70, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 8, \"fieldKey\": \"money\", \"label\": \"初始价值\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 80, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 9, \"fieldKey\": \"depreciate\", \"label\": \"折旧方法\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 90, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 10, \"fieldKey\": \"companyName\", \"label\": \"所属公司\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 100, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 11, \"fieldKey\": \"departmentName\", \"label\": \"使用部门\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 110, \"updateTime\": \"2026-10-17 11:52:51\"}, {\"id\": 12, \"fieldKey\": \"staffName\", \"label\": \"责任人\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 1','200',200,164,'2026-10-17 11:52:53'),(443,'admin','ADMIN','127.0.0.1','DELETE','/assets/delete/127',NULL,'200',200,8,'2026-10-17 11:52:53'),(444,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,5,'2026-10-17 11:53:09'),(445,'admin','ADMIN','127.0.0.1','PUT','/assetField/save','[{\"id\": 1, \"fieldKey\": \"no\", \"label\": \"设备编号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 10, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 2, \"fieldKey\": \"name\", \"label\": \"设备名称\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 20, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 3, \"fieldKey\": \"category\", \"label\": \"资产分类\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 30, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 4, \"fieldKey\": \"img\", \"label\": \"资产图片\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 40, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 5, \"fieldKey\": \"model\", \"label\": \"资产型号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 50, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 6, \"fieldKey\": \"num\", \"label\": \"数量\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 60, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 7, \"fieldKey\": \"date\", \"label\": \"购置日期\", \"fieldType\": \"date\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 70, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 8, \"fieldKey\": \"money\", \"label\": \"初始价值\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 80, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 9, \"fieldKey\": \"depreciate\", \"label\": \"折旧方法\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 90, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 10, \"fieldKey\": \"companyName\", \"label\": \"所属公司\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 100, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 11, \"fieldKey\": \"departmentName\", \"label\": \"所属部门\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 110, \"updateTime\": \"2026-10-17 11:52:52\"}, {\"id\": 12, \"fieldKey\": \"staffName\", \"label\": \"使用人\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 1','200',200,156,'2026-10-17 11:53:09'),(446,'admin','ADMIN','127.0.0.1','PUT','/assets/update','{\"id\":125,\"custom1\":\"2027-12-31\",\"custom2\":\"高\",\"custom3\":\"张工\"}','200',200,6,'2026-10-17 11:53:09'),(447,'admin','ADMIN','127.0.0.1','POST','/login','{\"username\":\"admin\",\"password\":\"***\",\"role\":\"ADMIN\"}','200',200,4,'2026-10-17 12:06:00'),(448,'admin','ADMIN','127.0.0.1','PUT','/assetField/save','[{\"id\": 1, \"fieldKey\": \"no\", \"label\": \"资产编号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 10, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 2, \"fieldKey\": \"name\", \"label\": \"资产名称\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 20, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 3, \"fieldKey\": \"category\", \"label\": \"资产分类\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 30, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 4, \"fieldKey\": \"img\", \"label\": \"资产图片\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 40, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 5, \"fieldKey\": \"model\", \"label\": \"资产型号\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 50, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 6, \"fieldKey\": \"num\", \"label\": \"数量\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 60, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 7, \"fieldKey\": \"date\", \"label\": \"购置日期\", \"fieldType\": \"date\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 70, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 8, \"fieldKey\": \"money\", \"label\": \"初始价值\", \"fieldType\": \"number\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 80, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 9, \"fieldKey\": \"depreciate\", \"label\": \"折旧方法\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 90, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 10, \"fieldKey\": \"companyName\", \"label\": \"所属公司\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 100, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 11, \"fieldKey\": \"departmentName\", \"label\": \"使用部门\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 110, \"updateTime\": \"2026-10-17 11:53:09\"}, {\"id\": 12, \"fieldKey\": \"staffName\", \"label\": \"责任人\", \"fieldType\": \"text\", \"options\": null, \"enabled\": 1, \"isSystem\": 1, \"sortNum\": 1','200',200,139,'2026-10-17 12:06:01'),(449,'admin','ADMIN','192.168.20.253','PUT','/assetField/save','[{\"id\":1,\"fieldKey\":\"no\",\"label\":\"资产编号\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":10,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":2,\"fieldKey\":\"name\",\"label\":\"资产名称\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":20,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":3,\"fieldKey\":\"category\",\"label\":\"资产分类\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":30,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":4,\"fieldKey\":\"img\",\"label\":\"资产图片\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":40,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":5,\"fieldKey\":\"model\",\"label\":\"资产型号\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":50,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":6,\"fieldKey\":\"num\",\"label\":\"数量\",\"fieldType\":\"number\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":60,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":7,\"fieldKey\":\"date\",\"label\":\"购置日期\",\"fieldType\":\"date\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":70,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":8,\"fieldKey\":\"money\",\"label\":\"初始价值\",\"fieldType\":\"number\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":80,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":9,\"fieldKey\":\"depreciate\",\"label\":\"折旧方法\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":90,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":10,\"fieldKey\":\"companyName\",\"label\":\"所属公司\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":100,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":11,\"fieldKey\":\"departmentName\",\"label\":\"使用部门\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":110,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":12,\"fieldKey\":\"staffName\",\"label\":\"使用人\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":120,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":13,\"fieldKey\":\"location\",\"label\":\"存放地点\",\"fieldType\":\"text\",\"options\":\"\",\"enabled\":1,\"isSystem\":1,\"sortNum\":130,\"updateTime\":\"2026-10-17 12:06:00\"},{\"id\":14,\"fieldKey\":\"status\",\"label\":\"资产状态\",\"','200',200,130,'2026-10-17 13:05:19');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_assets_in_staff_id_orphan`
--

DROP TABLE IF EXISTS `backup_assets_in_staff_id_orphan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_assets_in_staff_id_orphan` (
  `id` int NOT NULL DEFAULT '0' COMMENT 'ID',
  `assets_id` int DEFAULT NULL COMMENT '资产ID',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产分类',
  `model` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '规格型号',
  `num` int DEFAULT NULL COMMENT '入库数量',
  `money` decimal(12,2) DEFAULT NULL COMMENT '初始价值(单价)',
  `depreciate` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '折旧方法',
  `purchase_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '采购单号',
  `supplier` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '供应商',
  `department_id` int DEFAULT NULL COMMENT '使用部门ID',
  `manager_id` int DEFAULT NULL COMMENT '责任人ID',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '存放地点',
  `img` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产图片',
  `staff_id` int DEFAULT NULL COMMENT '操作人ID',
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '入库日期',
  `accept_date` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验收日期',
  `accept_user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验收人',
  `accept_result` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验收意见',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核状态',
  `audit_user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核人',
  `audit_date` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核日期',
  `reject_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '驳回原因'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_assets_in_staff_id_orphan`
--

LOCK TABLES `backup_assets_in_staff_id_orphan` WRITE;
/*!40000 ALTER TABLE `backup_assets_in_staff_id_orphan` DISABLE KEYS */;
INSERT INTO `backup_assets_in_staff_id_orphan` VALUES (10,32,'台式机','主机',NULL,1,NULL,NULL,NULL,NULL,12,NULL,NULL,NULL,4,'2026-09-12','2026-09-12',NULL,NULL,NULL,'通过','系统管理员','2026-09-12 13:54:05',NULL);
/*!40000 ALTER TABLE `backup_assets_in_staff_id_orphan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_assets_transfer_transfer_staff_id_orphan`
--

DROP TABLE IF EXISTS `backup_assets_transfer_transfer_staff_id_orphan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_assets_transfer_transfer_staff_id_orphan` (
  `id` int NOT NULL DEFAULT '0' COMMENT 'ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `assets_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产名称',
  `assets_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产编号',
  `transfer_time` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '调拨时间',
  `transfer_staff_id` int NOT NULL COMMENT '调拨人ID',
  `transfer_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '调拨人姓名',
  `from_staff_id` int DEFAULT NULL COMMENT '原使用人ID',
  `from_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原使用人姓名',
  `from_department_id` int DEFAULT NULL COMMENT '原部门ID',
  `from_department_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原部门名称',
  `from_location` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原存放地点',
  `to_staff_id` int DEFAULT NULL,
  `to_staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `to_department_id` int DEFAULT NULL,
  `to_department_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `to_location` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '新存放地点',
  `reason` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '调拨原因',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '待审批' COMMENT '调拨状态(待审批、已审批、已调拨、已拒绝)',
  `approver_id` int DEFAULT NULL COMMENT '审批人ID',
  `approver_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批人姓名',
  `approve_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批时间',
  `approve_comment` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批意见',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '备注',
  `create_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_assets_transfer_transfer_staff_id_orphan`
--

LOCK TABLES `backup_assets_transfer_transfer_staff_id_orphan` WRITE;
/*!40000 ALTER TABLE `backup_assets_transfer_transfer_staff_id_orphan` DISABLE KEYS */;
INSERT INTO `backup_assets_transfer_transfer_staff_id_orphan` VALUES (11,100,'示例资产','HM-CAT2026090001','2026-09-12 15:44:52',4,'系统管理员',NULL,NULL,NULL,NULL,'办公室',NULL,NULL,13,'11','办公室','1','已调拨',4,'系统管理员','2026-09-12 15:44:55',NULL,'','2026-09-12 15:44:52','2026-09-12 15:44:55');
/*!40000 ALTER TABLE `backup_assets_transfer_transfer_staff_id_orphan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_inventory_staff_id_orphan`
--

DROP TABLE IF EXISTS `backup_inventory_staff_id_orphan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_inventory_staff_id_orphan` (
  `id` int NOT NULL DEFAULT '0' COMMENT 'ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `inventory_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '盘点时间',
  `staff_id` int NOT NULL COMMENT '盘点人ID',
  `staff_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '盘点人姓名',
  `result` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '正常' COMMENT '盘点结果(正常、异常、丢失)',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '待盘点' COMMENT '盘点状态(待盘点、已盘点、已确认)',
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '盘点位置',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '备注',
  `create_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_inventory_staff_id_orphan`
--

LOCK TABLES `backup_inventory_staff_id_orphan` WRITE;
/*!40000 ALTER TABLE `backup_inventory_staff_id_orphan` DISABLE KEYS */;
INSERT INTO `backup_inventory_staff_id_orphan` VALUES (1,1,'2024-01-15 10:00:00',1,'张三','正常','已盘点','办公室A区','设备运行正常','2024-01-15 10:00:00','2024-01-15 10:00:00'),(2,2,'2024-01-15 11:00:00',1,'张三','正常','已盘点','办公室B区','设备运行正常','2024-01-15 11:00:00','2024-01-15 11:00:00'),(3,3,'2024-01-16 09:00:00',2,'李四','异常','已盘点','会议室','设备需要维修','2024-01-16 09:00:00','2024-01-16 09:00:00'),(4,4,'2024-01-16 14:00:00',2,'李四','正常','已盘点','办公室C区','设备运行正常','2024-01-16 14:00:00','2024-01-16 14:00:00'),(5,5,'2024-01-17 10:00:00',1,'张三','正常','已盘点','办公室D区','设备运行正常','2024-01-17 10:00:00','2024-01-17 10:00:00');
/*!40000 ALTER TABLE `backup_inventory_staff_id_orphan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类名称',
  `code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_category_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='资产分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (16,'笔记本电脑','DZ01');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) NOT NULL COMMENT '公司名称',
  `sort` int DEFAULT '0' COMMENT '排序',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` varchar(20) DEFAULT NULL,
  `update_time` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='分子公司';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (4,'赫玛科技',0,NULL,'2026-09-16 09:49:27','2026-09-16 09:49:27'),(5,'堡格丽',1,NULL,'2026-09-16 09:49:45','2026-09-16 09:49:45'),(6,'和晋智能',2,NULL,'2026-09-16 09:49:58','2026-09-16 09:49:58');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `pid` int DEFAULT NULL COMMENT '父级ID',
  `level` int DEFAULT NULL COMMENT '层级',
  `company_id` int DEFAULT NULL COMMENT '所属公司ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='部门信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (18,'国际业务部',NULL,NULL,1,5),(19,'国内业务部',NULL,NULL,1,5),(20,'采购中心',NULL,NULL,1,5),(21,'生产中心',NULL,NULL,1,5),(22,'品质中心',NULL,NULL,1,5),(23,'财务中心',NULL,NULL,1,5),(24,'人力行政中心',NULL,NULL,1,5),(25,'报价中心',NULL,NULL,1,5),(26,'钣金激光割组',NULL,NULL,1,6),(27,'钣金折弯组',NULL,NULL,1,6),(28,'钣金焊接组',NULL,NULL,1,6),(29,'钣金打磨组',NULL,NULL,1,6),(30,'品质部',NULL,NULL,1,6),(31,'技术部',NULL,NULL,1,6),(32,'仓储部',NULL,NULL,1,6),(33,'后勤支持组',NULL,NULL,1,6),(34,'人力行政中心',NULL,NULL,1,4),(35,'总经办',NULL,NULL,1,4),(36,'国际业务中心',NULL,NULL,1,4),(37,'技术中心',NULL,NULL,1,4),(38,'生产中心',NULL,NULL,1,4),(39,'供应链中心',NULL,NULL,1,4),(40,'财务中心',NULL,NULL,1,4),(41,'EHS中心',NULL,NULL,1,4);
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `assets_id` int NOT NULL COMMENT '资产ID',
  `inventory_time` varchar(20) NOT NULL COMMENT '盘点时间',
  `staff_id` int DEFAULT NULL COMMENT '盘点经办人，孤儿修复后可空',
  `staff_name` varchar(50) NOT NULL COMMENT '盘点人姓名',
  `result` varchar(20) NOT NULL DEFAULT '正常' COMMENT '盘点结果(正常、异常、丢失)',
  `status` varchar(20) NOT NULL DEFAULT '待盘点' COMMENT '盘点状态(待盘点、已盘点、已确认)',
  `location` varchar(100) DEFAULT NULL COMMENT '盘点位置',
  `comment` text COMMENT '备注',
  `create_time` varchar(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_assets_id` (`assets_id`),
  KEY `idx_staff_id` (`staff_id`),
  KEY `idx_inventory_time` (`inventory_time`),
  KEY `idx_result` (`result`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='资产盘点表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,1,'2024-01-15 10:00:00',NULL,'张三','正常','已盘点','办公室A区','设备运行正常','2024-01-15 10:00:00','2024-01-15 10:00:00'),(2,2,'2024-01-15 11:00:00',NULL,'张三','正常','已盘点','办公室B区','设备运行正常','2024-01-15 11:00:00','2024-01-15 11:00:00'),(3,3,'2024-01-16 09:00:00',NULL,'李四','异常','已盘点','会议室','设备需要维修','2024-01-16 09:00:00','2024-01-16 09:00:00'),(4,4,'2024-01-16 14:00:00',NULL,'李四','正常','已盘点','办公室C区','设备运行正常','2024-01-16 14:00:00','2024-01-16 14:00:00'),(5,5,'2024-01-17 10:00:00',NULL,'张三','正常','已盘点','办公室D区','设备运行正常','2024-01-17 10:00:00','2024-01-17 10:00:00');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_item`
--

DROP TABLE IF EXISTS `inventory_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` int NOT NULL COMMENT '盘点任务ID',
  `assets_id` int DEFAULT NULL COMMENT '资产ID',
  `assets_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产编号',
  `assets_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资产名称',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类',
  `department_id` int DEFAULT NULL,
  `department_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '台账部门',
  `staff_id` int DEFAULT NULL,
  `staff_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '台账责任人',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '台账地点',
  `actual_location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '实盘地点',
  `item_status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '未盘' COMMENT '未盘/正常/异常/盘亏/盘盈',
  `deal_status` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '差异处理状态：待处理/已处理（正常与未盘项为空）',
  `deal_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理方式',
  `deal_remark` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理说明',
  `deal_user_id` int DEFAULT NULL COMMENT '处理人ID',
  `deal_user` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理人姓名',
  `deal_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理时间',
  `is_extra` tinyint NOT NULL DEFAULT '0' COMMENT '1=范围外盘盈',
  `scanner_id` int DEFAULT NULL,
  `scanner_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scan_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task` (`task_id`),
  KEY `idx_assets` (`assets_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='资产盘点明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_item`
--

LOCK TABLES `inventory_item` WRITE;
/*!40000 ALTER TABLE `inventory_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_task`
--

DROP TABLE IF EXISTS `inventory_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务名称',
  `scope_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ALL' COMMENT '范围类型 ALL/DEPT/CATEGORY',
  `scope_id` int DEFAULT NULL COMMENT '范围ID（部门ID/分类ID）',
  `scope_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '范围名称快照',
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '盘点中' COMMENT '盘点中/已完成',
  `creator_id` int DEFAULT NULL,
  `creator_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_count` int NOT NULL DEFAULT '0' COMMENT '应盘总数(含盘盈)',
  `normal_count` int NOT NULL DEFAULT '0' COMMENT '正常数',
  `profit_count` int NOT NULL DEFAULT '0' COMMENT '盘盈数',
  `loss_count` int NOT NULL DEFAULT '0' COMMENT '盘亏数',
  `abnormal_count` int NOT NULL DEFAULT '0' COMMENT '异常数',
  `pending_diff_count` int NOT NULL DEFAULT '0' COMMENT '待处理差异数',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finish_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='资产盘点任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_task`
--

LOCK TABLES `inventory_task` WRITE;
/*!40000 ALTER TABLE `inventory_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建时间',
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='公告信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notify_log`
--

DROP TABLE IF EXISTS `notify_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notify_log` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event_key` varchar(50) DEFAULT NULL COMMENT '事件标识',
  `biz_type` varchar(30) DEFAULT NULL COMMENT '业务类型',
  `biz_id` int DEFAULT NULL COMMENT '业务单据ID',
  `title` varchar(200) DEFAULT NULL COMMENT '推送标题',
  `content` varchar(1000) DEFAULT NULL COMMENT '推送内容',
  `robot_id` int DEFAULT NULL COMMENT '机器人ID',
  `robot_name` varchar(100) DEFAULT NULL COMMENT '机器人名称',
  `status` varchar(10) DEFAULT NULL COMMENT '成功/失败',
  `response` varchar(500) DEFAULT NULL COMMENT '机器人接口返回内容',
  `create_time` varchar(20) DEFAULT NULL COMMENT '推送时间',
  PRIMARY KEY (`id`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notify_log`
--

LOCK TABLES `notify_log` WRITE;
/*!40000 ALTER TABLE `notify_log` DISABLE KEYS */;
INSERT INTO `notify_log` VALUES (31,'TEST','测试',NULL,'测试消息','**群机器人连通性测试**\\n> 来自固定资产管理系统',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-09-14 20:43:43'),(40,'RECEIVE_DUE','借用',NULL,'借用归还到期提醒','**借用归还到期提醒**\n> 待归还 2 笔（逾期 1 / 今日到期 0 / 明日到期 1）\n【已逾期】\n- null / 示例笔记本电脑（HM-CAT2026090017） / 应归还 2026-09-01\n【明日到期】\n- null / 示例笔记本电脑（HM-CAT2026090017） / 应归还 2026-09-15\n> 请及时联系借用人催还',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-09-14 21:10:00'),(41,'RECEIVE_DUE','借用',NULL,'借用归还到期提醒','**借用归还到期提醒**\n> 待归还 3 笔（逾期 1 / 今日到期 1 / 明日到期 1）\n【已逾期】\n- （未填写借用人） / 示例笔记本电脑（HM-CAT2026090017） / 应归还 2026-09-01\n【今日到期】\n- （未填写借用人） / 示例笔记本电脑（HM-CAT2026090017） / 应归还 2026-09-15\n【明日到期】\n- 111 / 示例笔记本电脑（HM-CAT2026090013） / 应归还 2026-09-16 / 18900200168\n> 请及时联系借用人催还',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-09-15 09:00:00'),(42,'RECEIVE_DUE','借用',NULL,'借用归还到期提醒','**借用归还到期提醒**\n> 待归还 3 笔（逾期 2 / 今日到期 1 / 明日到期 0）\n【已逾期】\n- （未填写借用人） / 示例笔记本电脑（HM-CAT2026090017） / 应归还 2026-09-01\n- （未填写借用人） / 示例笔记本电脑（HM-CAT2026090017） / 应归还 2026-09-15\n【今日到期】\n- 111 / 示例笔记本电脑（HM-CAT2026090013） / 应归还 2026-09-16 / 18900200168\n> 请及时联系借用人催还',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-09-16 09:00:00'),(43,'ASSETS_IN_SUBMIT','入库',29,'新的资产入库单待审核','**新的资产入库单待审核**\n> 资产：笔记本电脑\n> 资产分类：笔记本电脑\n> 采购单号：\n> 数量：1\n> 金额：\n> 提交人：系统管理员\n> 提交时间：2026-10-14 14:26:13\n> 请到「资产入库」页审核',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-10-14 14:26:14'),(44,'ASSETS_IN_PASS','入库',29,'资产入库审核通过','**资产入库审核通过**\n> 资产：笔记本电脑\n> 资产分类：笔记本电脑\n> 采购单号：\n> 数量：1\n> 金额：\n> 提交人：系统管理员\n> 审核人：系统管理员\n> 时间：2026-10-14 14:26:18',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-10-14 14:26:18'),(45,'RECEIVE_SUBMIT','借用',55,'新的资产借用申请待审核','**新的资产借用申请待审核**\n> 资产：ZZ现场编辑验证名（HM-DZ012026090001）\n> 借用人：ZZSCAN匿名验证\n> 联系方式：13800009999\n> 预计归还：2026-12-31\n> 备注：自动验证后清理\n> 提交时间：2026-10-15 18:33:50\n> 请到「资产借用」页审核',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-10-15 18:33:50'),(46,'REPAIR_SUBMIT','维修',35,'新的资产报修申请待处理','**新的资产报修申请待处理**\n> 资产：（）\n> 报修人：ZZSCAN匿名验证\n> 报修电话：13800009999\n> 故障描述：自动验证后清理\n> 提交时间：2026-10-15 18:33:50\n> 请到「资产维修」页处理',13,'资产提醒','成功','{\"errcode\":0,\"errmsg\":\"ok\"}','2026-10-15 18:33:50');
/*!40000 ALTER TABLE `notify_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notify_template`
--

DROP TABLE IF EXISTS `notify_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notify_template` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event_key` varchar(50) NOT NULL COMMENT '事件标识（如 SCRAP_PASS）',
  `biz_type` varchar(30) NOT NULL COMMENT '业务类型',
  `event_name` varchar(50) NOT NULL COMMENT '事件名称',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `title` varchar(200) DEFAULT NULL COMMENT '消息标题模板',
  `content` varchar(1000) DEFAULT NULL COMMENT '消息正文模板，支持 {占位符}',
  `create_time` varchar(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_key` (`event_key`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notify_template`
--

LOCK TABLES `notify_template` WRITE;
/*!40000 ALTER TABLE `notify_template` DISABLE KEYS */;
INSERT INTO `notify_template` VALUES (1,'SCRAP_PASS','报废','报废审批通过',1,'资产报废审批通过','**资产报废审批通过**\n> 资产：{assetsName}（{assetsNo}）\n> 报废类型：{scrapType}\n> 报废原因：{reason}\n> 申请人：{applicant}\n> 审批人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(2,'TRANSFER_PASS','调拨','调拨审批通过',1,'资产调拨审批通过','**资产调拨审批通过**\n> 资产：{assetsName}（{assetsNo}）\n> 调拨：{fromText} → {toText}\n> 调拨原因：{reason}\n> 申请人：{applicant}\n> 审批人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(3,'ASSETS_IN_PASS','入库','入库审核通过',1,'资产入库审核通过','**资产入库审核通过**\n> 资产：{assetsName}\n> 资产分类：{category}\n> 采购单号：{purchaseNo}\n> 数量：{num}\n> 金额：{money}\n> 提交人：{applicant}\n> 审核人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(4,'RECEIVE_PASS','借用','借用审核通过',1,'资产借用审核通过','**资产借用审核通过**\n> 资产：{assetsName}（{assetsNo}）\n> 借用人：{applicant}\n> 联系方式：{borrowerPhone}\n> 预计归还：{returnDate}\n> 审核人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(5,'REPAIR_PASS','维修','维修状态变更',1,'资产维修状态变更','**资产维修状态变更**\n> 资产：{assetsName}（{assetsCode}）\n> 当前状态：{status}\n> 故障描述：{faultDesc}\n> 报修人：{applicant}\n> 报修电话：{reporterPhone}\n> 操作人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(6,'SCRAP_REJECT','报废','报废审批驳回',0,'资产报废申请被驳回','**资产报废申请被驳回**\n> 资产：{assetsName}（{assetsNo}）\n> 申请人：{applicant}\n> 驳回原因：{approveComment}\n> 审批人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(7,'TRANSFER_REJECT','调拨','调拨审批驳回',0,'资产调拨申请被驳回','**资产调拨申请被驳回**\n> 资产：{assetsName}（{assetsNo}）\n> 申请人：{applicant}\n> 驳回原因：{approveComment}\n> 审批人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(8,'ASSETS_IN_REJECT','入库','入库审核驳回',0,'资产入库单被驳回','**资产入库单被驳回**\n> 资产：{assetsName}\n> 采购单号：{purchaseNo}\n> 提交人：{applicant}\n> 驳回原因：{approveComment}\n> 审核人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(9,'RECEIVE_REJECT','借用','借用审核驳回',0,'资产借用申请被驳回','**资产借用申请被驳回**\n> 资产：{assetsName}（{assetsNo}）\n> 借用人：{applicant}\n> 联系方式：{borrowerPhone}\n> 审核人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(10,'REPAIR_REJECT','维修','维修申请驳回',0,'资产维修申请被驳回','**资产维修申请被驳回**\n> 资产：{assetsName}（{assetsCode}）\n> 报修人：{applicant}\n> 报修电话：{reporterPhone}\n> 操作人：{approver}\n> 时间：{time}','2026-09-14 17:28:27','2026-09-14 17:29:00'),(21,'RECEIVE_SUBMIT','借用','借用申请提交',1,'新的资产借用申请待审核','**新的资产借用申请待审核**\n> 资产：{assetsName}（{assetsNo}）\n> 借用人：{applicant}\n> 联系方式：{borrowerPhone}\n> 预计归还：{returnDate}\n> 备注：{comment}\n> 提交时间：{time}\n> 请到「资产借用」页审核','2026-09-14 20:26:50','2026-09-14 20:33:33'),(22,'REPAIR_SUBMIT','维修','报修申请提交',1,'新的资产报修申请待处理','**新的资产报修申请待处理**\n> 资产：{assetsName}（{assetsCode}）\n> 报修人：{applicant}\n> 报修电话：{reporterPhone}\n> 故障描述：{faultDesc}\n> 提交时间：{time}\n> 请到「资产维修」页处理','2026-09-14 20:26:50','2026-09-14 20:33:33'),(23,'ASSETS_IN_SUBMIT','入库','入库单提交',1,'新的资产入库单待审核','**新的资产入库单待审核**\n> 资产：{assetsName}\n> 资产分类：{category}\n> 采购单号：{purchaseNo}\n> 数量：{num}\n> 金额：{money}\n> 提交人：{applicant}\n> 提交时间：{time}\n> 请到「资产入库」页审核','2026-09-14 20:26:50','2026-09-14 20:33:33'),(24,'TRANSFER_SUBMIT','调拨','调拨申请提交',1,'新的资产调拨申请待审批','**新的资产调拨申请待审批**\n> 资产：{assetsName}（{assetsNo}）\n> 调拨：{fromText} → {toText}\n> 调拨原因：{reason}\n> 申请人：{applicant}\n> 提交时间：{time}\n> 请到「资产调拨」页审批','2026-09-14 20:26:50','2026-09-14 20:33:33'),(25,'SCRAP_SUBMIT','报废','报废申请提交',1,'新的资产报废申请待审批','**新的资产报废申请待审批**\n> 资产：{assetsName}（{assetsNo}）\n> 报废类型：{scrapType}\n> 报废原因：{reason}\n> 申请人：{applicant}\n> 提交时间：{time}\n> 请到「资产报废」页审批','2026-09-14 20:26:50','2026-09-14 20:33:33'),(26,'ASSETS_IN_BATCH','入库','入库批量导入',1,'资产入库批量导入待审核','**资产入库批量导入待审核**\n> 导入条数：{count} 条\n> 涉及资产：{detail}\n> 提交人：{applicant}\n> 提交时间：{time}\n> 请到「资产入库」页审核','2026-09-14 20:33:33',NULL),(32,'RECEIVE_DUE','借用','借用到期提醒',1,'借用归还到期提醒','**借用归还到期提醒**\n> 待归还 {total} 笔（逾期 {overdueCount} / 今日到期 {todayCount} / 明日到期 {tomorrowCount}）\n{detail}> 请及时联系借用人催还','2026-09-14 20:59:10',NULL);
/*!40000 ALTER TABLE `notify_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `number_rule`
--

DROP TABLE IF EXISTS `number_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `number_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL COMMENT '规则名称',
  `pattern` varchar(200) NOT NULL COMMENT '编码模式',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `create_time` varchar(20) DEFAULT NULL,
  `update_time` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='资产编码规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `number_rule`
--

LOCK TABLES `number_rule` WRITE;
/*!40000 ALTER TABLE `number_rule` DISABLE KEYS */;
INSERT INTO `number_rule` VALUES (1,'HM','HM-{CAT}{YYYY}{MM}{SEQ:3}',1,'2026-09-12 10:50:39','2026-09-12 13:51:21');
/*!40000 ALTER TABLE `number_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `robot_config`
--

DROP TABLE IF EXISTS `robot_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `robot_config` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) NOT NULL COMMENT '机器人名称',
  `type` varchar(20) NOT NULL DEFAULT 'wechat' COMMENT '类型：wechat=企业微信群机器人',
  `webhook_url` varchar(500) NOT NULL COMMENT 'Webhook 地址',
  `secret` varchar(200) DEFAULT NULL COMMENT '加签密钥（机器人开启加签时填，未开启留空）',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` varchar(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(20) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='群机器人配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `robot_config`
--

LOCK TABLES `robot_config` WRITE;
/*!40000 ALTER TABLE `robot_config` DISABLE KEYS */;
INSERT INTO `robot_config` VALUES (13,'资产提醒','wechat','https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=cc3bc2cd-1282-49d4-baff-808290dfb532',NULL,1,NULL,'2026-09-14 20:43:26','2026-09-14 20:43:26');
/*!40000 ALTER TABLE `robot_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `emp_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '工号',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色标识',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '电话',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `id_card` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证号',
  `birth_date` date DEFAULT NULL COMMENT '出生日期',
  `education` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学历',
  `native_place` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '籍贯',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '家庭住址',
  `emergency_contact` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紧急联系人',
  `emergency_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紧急联系电话',
  `department_id` int DEFAULT NULL,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '职位',
  `entry_date` date DEFAULT NULL COMMENT '入职日期',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '在职' COMMENT '状态：在职/离职',
  `leave_date` date DEFAULT NULL COMMENT '离职日期',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_staff_emp_no` (`emp_no`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='员工';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (34,'孙纪猛',NULL,'202cb962ac59075b964b07152d234b70','孙纪猛',NULL,NULL,'STAFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,37,NULL,NULL,'在职',NULL,NULL),(35,'林燕',NULL,'202cb962ac59075b964b07152d234b70','林燕',NULL,NULL,'STAFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,40,NULL,NULL,'在职',NULL,NULL),(41,'cs',NULL,'202cb962ac59075b964b07152d234b70','cs',NULL,NULL,'STAFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'在职',NULL,NULL);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `config_key` varchar(50) NOT NULL COMMENT '配置键',
  `config_value` varchar(500) DEFAULT NULL COMMENT '配置值',
  `remark` varchar(200) DEFAULT NULL COMMENT '说明',
  `update_time` varchar(20) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='页面/站点配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES (1,'system_name','赫玛集团-固资系统','系统名称（后台顶栏、登录页标题、浏览器标签）','2026-10-17 10:23:42'),(2,'browser_title','赫玛集团-固资系统','浏览器标签标题（留空则跟随系统名称）','2026-10-17 10:23:42'),(3,'login_subtitle','欢迎使用','登录页副标题','2026-10-17 10:23:42'),(4,'login_bg','/files/1792052802911-1111.jpg','登录页壁纸图片地址（留空用内置背景图）','2026-10-17 10:23:42'),(5,'logo','/files/1792052821518-微信图片_20251128154530_195_1705.png','Logo 图片地址（留空用内置 Logo）','2026-10-17 10:23:42'),(6,'footer_text','2026赫玛科技版权所有','页脚版权信息（留空则不显示页脚）','2026-10-17 10:23:42'),(7,'dashboard_welcome','欢迎使用赫玛集团固定资产管理系统','驾驶舱欢迎词（显示为「您好，XXX！欢迎词」）','2026-10-17 10:23:42'),(29,'scan_fields','no,category,model,status,date,money,departmentName,staffName,location,comment,img,company','扫码页显示字段（逗号分隔）','2026-10-17 13:05:19'),(46,'scan_title','资产卡片','扫码页卡片标题','2026-10-17 10:23:42'),(47,'scan_footer','赫玛集团2026','扫码页底部文字','2026-10-17 10:23:42'),(48,'scan_borrow_text','临时借用','扫码页借用按钮文字','2026-10-17 10:23:42'),(49,'scan_repair_text','故障反馈','扫码页报修按钮文字','2026-10-17 10:23:42');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_menu` (
  `id` int NOT NULL COMMENT '菜单ID（固定编号）',
  `parent_id` int DEFAULT '0' COMMENT '父菜单ID，0=顶级',
  `name` varchar(64) NOT NULL COMMENT '菜单名称',
  `path` varchar(128) DEFAULT NULL COMMENT '路由路径（目录为空）',
  `api` varchar(255) DEFAULT NULL COMMENT '该菜单控制的后端接口路径前缀，多个用逗号分隔',
  `icon` varchar(64) DEFAULT NULL COMMENT '图标 class',
  `type` tinyint DEFAULT '2' COMMENT '类型：1=目录 2=菜单',
  `sort` int DEFAULT '0' COMMENT '排序',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (1,0,'资产驾驶舱','/home','/dashboard','el-icon-data-analysis',2,1,'2026-09-12 16:47:59'),(10,0,'资产管理',NULL,NULL,'el-icon-box',1,10,'2026-09-12 16:47:59'),(11,10,'固定资产台账','/assets','/assets,/asset,/assetsDetail',NULL,2,1,'2026-09-12 16:47:59'),(12,10,'资产入库','/assetsIn','/assetsIn',NULL,2,2,'2026-09-12 16:47:59'),(13,10,'资产调拨','/assetsTransfer','/assetsTransfer',NULL,2,3,'2026-09-12 16:47:59'),(14,10,'资产借用','/assetsReceive','/assetsReceive',NULL,2,4,'2026-09-12 16:47:59'),(15,10,'资产盘点','/assetsInventory','/assetsInventory,/inventory',NULL,2,5,'2026-09-12 16:47:59'),(16,10,'资产维修','/assetsRepair','/assetsRepair',NULL,2,6,'2026-09-12 16:47:59'),(17,10,'资产报废','/assetsScrap','/assetsScrap',NULL,2,7,'2026-09-12 16:47:59'),(18,10,'个人资产','/staffAssets','/staffAssets',NULL,2,8,'2026-09-12 16:47:59'),(20,0,'基础资料',NULL,NULL,'el-icon-notebook-2',1,20,'2026-09-12 16:47:59'),(21,20,'资产分类','/category','/category',NULL,2,4,'2026-09-12 16:47:59'),(22,20,'部门信息','/department','/department',NULL,2,2,'2026-09-12 16:47:59'),(23,20,'资产编码规则','/numberRule','/numberRule',NULL,2,5,'2026-09-12 16:47:59'),(24,20,'自定义字段','/customFields','/assetField',NULL,2,6,'2026-09-12 16:47:59'),(30,0,'系统集成',NULL,NULL,'el-icon-connection',1,30,'2026-09-12 16:47:59'),(40,0,'权限管理',NULL,NULL,'el-icon-key',1,40,'2026-09-12 16:47:59'),(41,40,'角色权限','/rolePerm','/role,/menu',NULL,2,1,'2026-09-12 16:47:59'),(42,40,'管理员信息','/admin','/admin',NULL,2,2,'2026-09-12 16:47:59'),(43,20,'员工信息','/staff','/staff',NULL,2,3,'2026-09-12 16:47:59'),(50,0,'系统管理',NULL,NULL,'el-icon-setting',1,50,'2026-09-12 16:47:59'),(51,50,'公告信息','/notice','/notice',NULL,2,1,'2026-09-12 16:47:59'),(52,50,'日志审计','/auditLog','/auditLog',NULL,2,2,'2026-09-12 16:47:59'),(53,30,'机器人配置','/robotConfig','/robotConfig',NULL,2,2,'2026-09-14 17:29:00'),(54,30,'通知信息','/notifyConfig','/notify',NULL,2,3,'2026-09-14 17:29:00'),(55,20,'公司信息','/company','/company',NULL,2,1,'2026-09-14 20:59:10'),(56,50,'页面设置','/pageSetting','/sysConfig',NULL,2,3,'2026-10-15 16:12:40');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(64) NOT NULL COMMENT '角色名称',
  `code` varchar(64) NOT NULL COMMENT '角色标识（如 SUPER_ADMIN）',
  `description` varchar(255) DEFAULT NULL COMMENT '角色描述',
  `sort` int DEFAULT '0' COMMENT '排序',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'超级管理员','SUPER_ADMIN','拥有系统全部菜单权限，可管理角色与管理员',1,'2026-09-12 16:47:59','2026-09-12 16:47:59'),(2,'资产管理员','ASSET_ADMIN','负责资产全流程与基础资料，不能分配权限和查看审计日志',2,'2026-09-12 16:47:59','2026-09-12 16:47:59'),(3,'只读人员','VIEWER','仅可查看资产驾驶舱、固定资产台账和公告',3,'2026-09-12 16:47:59','2026-09-12 16:47:59');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_menu`
--

DROP TABLE IF EXISTS `sys_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_menu` (
  `role_id` int NOT NULL COMMENT '角色ID',
  `menu_id` int NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色菜单关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_menu`
--

LOCK TABLES `sys_role_menu` WRITE;
/*!40000 ALTER TABLE `sys_role_menu` DISABLE KEYS */;
INSERT INTO `sys_role_menu` VALUES (1,1),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,20),(1,21),(1,22),(1,23),(1,24),(1,30),(1,40),(1,41),(1,42),(1,43),(1,50),(1,51),(1,52),(1,53),(1,54),(1,55),(1,56),(2,1),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15),(2,16),(2,17),(2,20),(2,21),(2,22),(2,24),(2,43),(2,55),(3,1),(3,10),(3,11),(3,50),(3,51),(3,56);
/*!40000 ALTER TABLE `sys_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'xm-assets'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-17 13:14:51
